T2M TikTok View Counter — v1.11.0 (Chrome Side Panel)
====================================================

NÂNG CẤP
1) Bấm biểu tượng Extension ở góc phải Chrome -> mở Chrome Side Panel.
   Side Panel dùng được trên MỌI WEBSITE, không cần đang mở TikTok.
2) Dán URL video TikTok (mỗi dòng một link) -> Bắt đầu Batch.
   Extension tự mở một tab TikTok phục vụ chụp ảnh; cần để tab này
   hiển thị ở phía trước khi chụp. Không dùng để chụp các tab khác.
3) TẮT "Views + Engagement": giữ chụp thumbnail có Views tại profile.
4) BẬT "Views + Engagement": MỞ THẲNG từng VIDEO, không chụp
   thumbnail trung gian. Đợi Views overlay + nút Like/Comment/Share
   xuất hiện; lưu MỘT ảnh JPG/video với vùng video + các chỉ số.
5) Kết quả tiến độ đồng bộ về Side Panel, có nút Dừng, mở tab đang chạy,
   xuất Debug Log. Giữ log debug, multi-channel và tính năng cũ.
6) Hạn chế gọi lại API lấy Views: khi thất bại chờ 45 giây, khi thành công
   chờ 2 phút mới thử làm mới từ API để giảm yêu cầu không cần thiết.
7) Kiểm tra tab hiện hoạt trước khi captureVisibleTab; tránh chụp nhầm
   tab Gmail/Sheets/website khác khi đang xử lý.

CÀI ĐẶT / CẬP NHẬT (CHROME)
1. Giải nén ZIP vào một thư mục cố định (ví dụ D:\T2M\TikTokView-v1.11.0).
2. Mở chrome://extensions -> bật Developer mode.
3. Nếu đang dùng bản 1.10.3 cũ: Remove bản cũ để không có 2 Extension
   cùng hoạt động đồng thời. (Lưu lại dữ liệu/debug bạn cần trước.)
4. Bấm Load unpacked -> chọn THƯ MỤC có manifest.json.
5. Bấm biểu tượng mảnh ghép (Extensions) -> Pin "TikTok View Counter".
6. Bấm icon Extension -> Chrome Side Panel mở ra ở bên phải hoặc bên trái,
   theo cài đặt Side Panel của Chrome. Có thể đổi bên trong cài đặt Chrome.
7. Dán 1 hoặc nhiều link video TikTok chuẩn:
   https://www.tiktok.com/@username/video/1234567890123456789
8. Tick Views + Engagement nếu muốn chụp chung một ảnh. Bấm Bắt đầu.

LƯU Ý
- Google Chrome >= 116. Không cần đăng nhập/nhập link tại TikTok thủ công;
  nhưng vẫn cần truy cập được TikTok để lấy ảnh screenshot.
- Tùy giao diện/language của TikTok, chỉ số có thể không xuất hiện; khi đó
  Extension báo lỗi trong tiến độ. Chưa kiểm thử được live ở TikTok thật.
- Nếu TikTok yêu cầu xác minh/CAPTCHA, giải quyết bằng thao tác chính chủ;
  tool KHÔNG cố vượt chặn, KHÔNG bảo đảm tránh bị TikTok hạn chế truy cập.
- Google Chrome captureVisibleTab yêu cầu quyền <all_urls> hoặc activeTab.
  Bản local giữ quyền <all_urls> từ v1.10.3 để chụp hàng loạt ổn định;
  cần xem xét thu hẹp quyền/thiết kế lại trước khi nộp Chrome Web Store.
- Số Views overlay ở mã cũ có thể điều chỉnh thủ công; ảnh màn hình
  KHÔNG phải xác nhận số liệu chính thức từ TikTok API.
- Không hỗ trợ Engagement cho /photo/ (chế độ Views/thumbnail vẫn hỗ trợ).
- Nút Dừng từ Side Panel đóng tab TikTok mà Extension đã tạo để đảm bảo dừng hẳn.

FILES
manifest.json | background.js | content.js | style.css |
sidepanel.html | sidepanel.css | sidepanel.js | icon16/48/128.png

Kiểm thử: JavaScript syntax (node --check) + background logic mock (PASS).
Cần thử thủ công trên Chrome + TikTok thật trước khi phát hành rộng rãi.

"""Validate and package this Chrome extension for review/testing.

Usage: python tools/build_extension.py
Result: dist/t2m-tiktok-extension-v<VERSION>.zip
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json, re, sys

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'dist'
SOURCE_FILES = [
    'manifest.json', 'background.js', 'content.js', 'style.css',
    'sidepanel.html', 'sidepanel.js', 'sidepanel.css',
    'icon16.png', 'icon48.png', 'icon128.png',
]

def main():
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    assert manifest.get('manifest_version') == 3, 'Manifest V3 is required'
    version = manifest.get('version', '')
    assert re.fullmatch(r'\d+\.\d+\.\d+(?:\.\d+)?', version), 'Invalid Chrome extension version'
    missing = [f for f in SOURCE_FILES if not (ROOT / f).is_file()]
    assert not missing, f'Missing extension files: {missing}'
    # Ensure every referenced asset remains inside the packaged extension.
    references = [manifest['background']['service_worker'],
                  manifest['side_panel']['default_path']]
    for item in manifest.get('content_scripts', []):
        references += item.get('js', []) + item.get('css', [])
    for mapping in [manifest.get('icons', {}), manifest.get('action', {}).get('default_icon', {})]:
        references += list(mapping.values())
    for path in references:
        assert path in SOURCE_FILES, f'Asset not packaged: {path}'
    OUT.mkdir(exist_ok=True)
    dest = OUT / f't2m-tiktok-extension-v{version}.zip'
    with ZipFile(dest, 'w', ZIP_DEFLATED) as z:
        for name in SOURCE_FILES:
            z.write(ROOT / name, arcname=name)
    with ZipFile(dest) as z:
        assert z.namelist()[0] == 'manifest.json'
        json.loads(z.read('manifest.json'))
    print(f'Build complete: {dest} ({dest.stat().st_size:,} bytes)')

if __name__ == '__main__':
    try:
        main()
    except (KeyError, AssertionError, FileNotFoundError, json.JSONDecodeError) as e:
        print(f'Build failed: {e}', file=sys.stderr)
        sys.exit(1)

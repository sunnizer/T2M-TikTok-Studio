(() => {
    const COUNTER_ID = "tt-view-counter";
    const VALUE_ID = "tt-view-counter-value";
    const INPUT_ID = "tt-view-counter-input";

    const UPDATE_INTERVAL = 700;
    const FETCH_RETRY_COOLDOWN = 2 * 60 * 1000; // successful view fetch: refresh no more than every 2 minutes
    const FETCH_FAILED_RETRY_COOLDOWN = 45 * 1000; // failed requests: slow backoff
    const MAX_CACHE_AGE = 10 * 60 * 1000;
    const CUSTOM_STORAGE_KEY = "tt-view-counter-custom-values-v1";

    const FAST_RETRY_DELAYS = [0, 100, 250, 500, 900, 1500, 2500, 4000, 6500, 10000, 16000, 24000];

    let lastUrl = "";
    let lastVideoId = "";
    let updateSequence = 0;
    let mutationTimer = null;
    let editingVideoId = "";
    let lastRealViews = null;
    let retryTimers = [];

    const viewCache = new Map();
    const fetchInFlight = new Map();
    const lastFetchAttempt = new Map();
    const lastFetchSuccessful = new Map();

    function getCurrentVideoId() {
        const href = String(window.location.href || "");
        const pathname = String(window.location.pathname || "");

        let match = pathname.match(/\/(?:video|photo)\/(\d+)/i);
        if (match) {
            return match[1];
        }

        match = href.match(/[?&](?:item_id|itemId|modal_id)=(\d+)/i);
        if (match) {
            return match[1];
        }

        return null;
    }

    function normalizeCount(value) {
        const number = Number(value);
        return Number.isFinite(number) && number >= 0 ? Math.round(number) : null;
    }


    function readCustomValues() {
        try {
            const raw = localStorage.getItem(CUSTOM_STORAGE_KEY);
            const parsed = raw ? JSON.parse(raw) : {};
            return parsed && typeof parsed === "object" ? parsed : {};
        } catch (error) {
            return {};
        }
    }

    function writeCustomValues(values) {
        try {
            localStorage.setItem(CUSTOM_STORAGE_KEY, JSON.stringify(values));
        } catch (error) {
            console.debug("[TikTok View Counter] Không lưu được số tùy chỉnh:", error);
        }
    }

    function getCustomViews(videoId) {
        if (!videoId) {
            return null;
        }

        const values = readCustomValues();
        return normalizeCount(values[String(videoId)]);
    }

    function setCustomViews(videoId, views) {
        if (!videoId) {
            return;
        }

        const normalized = normalizeCount(views);
        if (normalized === null) {
            return;
        }

        const values = readCustomValues();
        values[String(videoId)] = normalized;
        writeCustomValues(values);
    }

    function clearCustomViews(videoId) {
        if (!videoId) {
            return;
        }

        const values = readCustomValues();
        delete values[String(videoId)];
        writeCustomValues(values);
    }

    function parseEditableCount(value) {
        const cleaned = String(value || "")
            .trim()
            .replace(/\s+/g, "")
            .replace(/,/g, "")
            .toUpperCase();

        if (!cleaned) {
            return null;
        }

        const match = cleaned.match(/^([0-9]+(?:\.[0-9]+)?)\s*([KMB])?$/);
        if (!match) {
            return null;
        }

        const base = Number(match[1]);
        if (!Number.isFinite(base) || base < 0) {
            return null;
        }

        const multiplier =
            match[2] === "K" ? 1e3 :
            match[2] === "M" ? 1e6 :
            match[2] === "B" ? 1e9 : 1;

        return Math.round(base * multiplier);
    }

    function cacheViews(videoId, views) {
        if (!videoId || views === null) {
            return;
        }

        viewCache.set(String(videoId), {
            views,
            time: Date.now()
        });
    }

    function getCachedViews(videoId) {
        if (!videoId) {
            return null;
        }

        const cached = viewCache.get(String(videoId));
        if (!cached) {
            return null;
        }

        if (Date.now() - cached.time > MAX_CACHE_AGE) {
            viewCache.delete(String(videoId));
            return null;
        }

        return cached.views;
    }

    function extractPlayCountFromObject(obj) {
        if (!obj || typeof obj !== "object") {
            return null;
        }

        const directCandidates = [
            obj?.stats?.playCount,
            obj?.statistics?.playCount,
            obj?.statsV2?.playCount,
            obj?.playCount,
            obj?.play_count,
            obj?.playcount
        ];

        for (const candidate of directCandidates) {
            const views = normalizeCount(candidate);
            if (views !== null) {
                return views;
            }
        }

        return null;
    }

    function objectMatchesVideoId(obj, videoId) {
        if (!obj || typeof obj !== "object" || !videoId) {
            return false;
        }

        const ids = [
            obj.id,
            obj.itemId,
            obj.item_id,
            obj.aweme_id,
            obj.videoId,
            obj.video_id
        ];

        return ids.some((id) => id !== undefined && id !== null && String(id) === String(videoId));
    }

    function extractViewsFromItemStruct(itemStruct, videoId) {
        if (!itemStruct || typeof itemStruct !== "object") {
            return null;
        }

        if (videoId && itemStruct.id && String(itemStruct.id) !== String(videoId)) {
            return null;
        }

        return extractPlayCountFromObject(itemStruct);
    }

    function extractViewsDeep(data, videoId) {
        if (!data || typeof data !== "object" || !videoId) {
            return null;
        }

        const visited = new WeakSet();
        const queue = [{ value: data, depth: 0, key: "" }];
        let inspected = 0;
        const MAX_OBJECTS = 18000;
        const MAX_DEPTH = 14;

        while (queue.length && inspected < MAX_OBJECTS) {
            const current = queue.shift();
            const value = current.value;

            if (!value || typeof value !== "object") {
                continue;
            }

            if (visited.has(value)) {
                continue;
            }

            visited.add(value);
            inspected++;

            if (objectMatchesVideoId(value, videoId) || String(current.key) === String(videoId)) {
                const views = extractPlayCountFromObject(value);
                if (views !== null) {
                    return views;
                }
            }

            if (Object.prototype.hasOwnProperty.call(value, String(videoId))) {
                const keyedValue = value[String(videoId)];
                const views = extractPlayCountFromObject(keyedValue);
                if (views !== null) {
                    return views;
                }
            }

            if (current.depth >= MAX_DEPTH) {
                continue;
            }

            if (Array.isArray(value)) {
                const limit = Math.min(value.length, 500);
                for (let i = 0; i < limit; i++) {
                    const child = value[i];
                    if (child && typeof child === "object") {
                        queue.push({ value: child, depth: current.depth + 1, key: String(i) });
                    }
                }
            } else {
                const entries = Object.entries(value);
                const limit = Math.min(entries.length, 700);
                for (let i = 0; i < limit; i++) {
                    const [key, child] = entries[i];
                    if (child && typeof child === "object") {
                        queue.push({ value: child, depth: current.depth + 1, key });
                    }
                }
            }
        }

        return null;
    }

    function extractViewsFromJson(data, videoId) {
        if (!data || typeof data !== "object") {
            return null;
        }

        const universalItem =
            data?.__DEFAULT_SCOPE__?.["webapp.video-detail"]
                ?.itemInfo?.itemStruct;

        let views = extractViewsFromItemStruct(universalItem, videoId);
        if (views !== null) {
            return views;
        }

        const sigiItem = data?.ItemModule?.[String(videoId)];
        views = extractViewsFromItemStruct(sigiItem, videoId);
        if (views !== null) {
            return views;
        }

        views = extractViewsFromItemStruct(data?.itemInfo?.itemStruct, videoId);
        if (views !== null) {
            return views;
        }

        return extractViewsDeep(data, videoId);
    }

    function extractViewsFromRawText(text, videoId) {
        if (!text || !videoId) {
            return null;
        }

        const raw = String(text);
        if (!raw.includes(String(videoId)) || !/playCount|play_count|playcount/i.test(raw)) {
            return null;
        }

        const idText = String(videoId);
        let startIndex = 0;
        let foundIndex = raw.indexOf(idText, startIndex);
        let attempts = 0;

        while (foundIndex !== -1 && attempts < 12) {
            const windowStart = Math.max(0, foundIndex - 8000);
            const windowEnd = Math.min(raw.length, foundIndex + 30000);
            const snippet = raw.slice(windowStart, windowEnd);

            const patterns = [
                /["']playCount["']\s*:\s*["']?(\d+)["']?/i,
                /["']play_count["']\s*:\s*["']?(\d+)["']?/i,
                /["']playcount["']\s*:\s*["']?(\d+)["']?/i
            ];

            for (const pattern of patterns) {
                const match = snippet.match(pattern);
                if (match) {
                    const views = normalizeCount(match[1]);
                    if (views !== null) {
                        return views;
                    }
                }
            }

            startIndex = foundIndex + idText.length;
            foundIndex = raw.indexOf(idText, startIndex);
            attempts++;
        }

        return null;
    }

    function parseJsonScript(script, videoId) {
        if (!script || !script.textContent) {
            return null;
        }

        const text = script.textContent;

        try {
            const data = JSON.parse(text);
            const views = extractViewsFromJson(data, videoId);
            if (views !== null) {
                return views;
            }
        } catch (error) {
            // Một số script không phải JSON thuần. Regex fallback bên dưới sẽ xử lý.
        }

        return extractViewsFromRawText(text, videoId);
    }


    function getViewsFromDocument(doc, videoId) {
        if (!doc || !videoId) {
            return null;
        }

        const priorityScripts = [
            doc.getElementById("__UNIVERSAL_DATA_FOR_REHYDRATION__"),
            doc.getElementById("SIGI_STATE"),
            doc.querySelector('script[id*="UNIVERSAL_DATA"]'),
            doc.querySelector('script[id*="SIGI"]')
        ].filter(Boolean);

        const seen = new Set();

        for (const script of priorityScripts) {
            seen.add(script);
            const views = parseJsonScript(script, videoId);
            if (views !== null) {
                return views;
            }
        }

        const scripts = Array.from(doc.querySelectorAll("script"));
        let checked = 0;

        for (const script of scripts) {
            if (seen.has(script) || !script.textContent) {
                continue;
            }

            const text = script.textContent;
            if (!text.includes(String(videoId))) {
                continue;
            }

            if (!/playCount|play_count|playcount/i.test(text)) {
                continue;
            }

            const views = parseJsonScript(script, videoId);
            if (views !== null) {
                return views;
            }

            checked++;
            if (checked >= 30) {
                break;
            }
        }

        return null;
    }

    function parseCompactCount(text) {
        if (!text) {
            return null;
        }

        const cleaned = String(text)
            .trim()
            .replace(/,/g, "")
            .toUpperCase();

        const match = cleaned.match(/([0-9]+(?:\.[0-9]+)?)\s*([KMB])?/);
        if (!match) {
            return null;
        }

        const base = Number(match[1]);
        if (!Number.isFinite(base)) {
            return null;
        }

        const multiplier =
            match[2] === "K" ? 1e3 :
            match[2] === "M" ? 1e6 :
            match[2] === "B" ? 1e9 : 1;

        return Math.round(base * multiplier);
    }

    function isElementVisible(element) {
        if (!element || !element.isConnected) {
            return false;
        }

        const rect = element.getBoundingClientRect();
        if (
            rect.width <= 0 ||
            rect.height <= 0 ||
            rect.bottom <= 0 ||
            rect.top >= window.innerHeight ||
            rect.right <= 0 ||
            rect.left >= window.innerWidth
        ) {
            return false;
        }

        const style = window.getComputedStyle(element);
        return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
    }

    function getViewsFromDom() {
        const selectors = [
            '[data-e2e="browse-video-count"]',
            '[data-e2e="video-views"]',
            '[data-e2e="video-view-count"]',
            '[data-e2e="browse-video-views"]',
            '[data-e2e*="view-count"]',
            '[data-e2e*="video-count"]'
        ];

        for (const selector of selectors) {
            const elements = Array.from(document.querySelectorAll(selector));

            for (const element of elements) {
                if (!isElementVisible(element)) {
                    continue;
                }

                const views = parseCompactCount(element.textContent || element.getAttribute("aria-label"));
                if (views !== null) {
                    return views;
                }
            }
        }

        const ariaElements = Array.from(
            document.querySelectorAll('[aria-label*="view" i], [aria-label*="lượt xem" i]')
        );

        for (const element of ariaElements) {
            if (!isElementVisible(element)) {
                continue;
            }

            const label = element.getAttribute("aria-label") || "";
            const views = parseCompactCount(label);
            if (views !== null) {
                return views;
            }
        }

        return null;
    }

    async function fetchHtmlViews(videoId) {
        try {
            const url = new URL(window.location.href);
            url.hash = "";

            const response = await fetch(url.toString(), {
                method: "GET",
                credentials: "include",
                cache: "no-store",
                headers: {
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
                }
            });

            if (!response.ok) {
                return null;
            }

            const html = await response.text();
            if (!html) {
                return null;
            }

            const parsedDoc = new DOMParser().parseFromString(html, "text/html");
            return getViewsFromDocument(parsedDoc, videoId);
        } catch (error) {
            console.debug("[TikTok View Counter] HTML fallback thất bại:", error);
            return null;
        }
    }

    async function fetchApiViews(videoId) {
        const endpoints = [
            `/api/item/detail/?aid=1988&itemId=${encodeURIComponent(videoId)}`,
            `/api/item/detail/?itemId=${encodeURIComponent(videoId)}`
        ];

        for (const endpoint of endpoints) {
            try {
                const response = await fetch(endpoint, {
                    method: "GET",
                    credentials: "include",
                    cache: "no-store",
                    headers: {
                        "Accept": "application/json,text/plain,*/*"
                    }
                });

                if (!response.ok) {
                    continue;
                }

                const text = await response.text();
                if (!text) {
                    continue;
                }

                let views = null;

                try {
                    const data = JSON.parse(text);
                    views = extractViewsFromJson(data, videoId);
                } catch (error) {
                    views = extractViewsFromRawText(text, videoId);
                }

                if (views !== null) {
                    return views;
                }
            } catch (error) {
                console.debug("[TikTok View Counter] API fallback thất bại:", error);
            }
        }

        return null;
    }

    async function fetchViewsForVideo(videoId) {
        if (!videoId) {
            return null;
        }

        const key = String(videoId);
        const now = Date.now();
        const lastAttempt = lastFetchAttempt.get(key) || 0;

        if (fetchInFlight.has(key)) {
            return fetchInFlight.get(key);
        }

        const retryAfter = lastFetchSuccessful.get(key)
            ? FETCH_RETRY_COOLDOWN : FETCH_FAILED_RETRY_COOLDOWN;
        if (now - lastAttempt < retryAfter) {
            return null;
        }

        lastFetchAttempt.set(key, now);

        const promise = (async () => {
            try {
                const results = await Promise.allSettled([
                    fetchApiViews(videoId),
                    fetchHtmlViews(videoId)
                ]);

                for (const result of results) {
                    if (result.status === "fulfilled" && result.value !== null) {
                        cacheViews(videoId, result.value);
                        lastFetchSuccessful.set(key, true);
                        return result.value;
                    }
                }

                lastFetchSuccessful.set(key, false);
                return null;
            } finally {
                fetchInFlight.delete(key);
            }
        })();

        fetchInFlight.set(key, promise);
        return promise;
    }

    async function getViews(videoId) {
        let views = getViewsFromDocument(document, videoId);

        if (views !== null) {
            cacheViews(videoId, views);
            return views;
        }

        views = getViewsFromDom();

        if (views !== null) {
            cacheViews(videoId, views);
            return views;
        }

        const cached = getCachedViews(videoId);

        if (cached !== null) {
            // Làm mới ngầm, nhưng hiển thị cache ngay để không bị mất số.
            fetchViewsForVideo(videoId);
            return cached;
        }

        return await fetchViewsForVideo(videoId);
    }

    function formatNumber(number) {
        return Number(number).toLocaleString("en-US");
    }


    function findActiveVideo() {
        const videos = Array.from(document.querySelectorAll("video"));

        const visibleVideos = videos
            .map((video) => {
                const rect = video.getBoundingClientRect();
                const style = window.getComputedStyle(video);

                return {
                    video,
                    rect,
                    area: rect.width * rect.height,
                    centerDistance: Math.abs((rect.top + rect.bottom) / 2 - window.innerHeight / 2),
                    style
                };
            })
            .filter(({ video, rect, style }) => {
                return (
                    rect.width >= 160 &&
                    rect.height >= 160 &&
                    rect.bottom > 0 &&
                    rect.right > 0 &&
                    rect.top < window.innerHeight &&
                    rect.left < window.innerWidth &&
                    style.display !== "none" &&
                    style.visibility !== "hidden" &&
                    video.offsetParent !== null
                );
            })
            .sort((a, b) => {
                const areaDiff = b.area - a.area;
                if (Math.abs(areaDiff) > 10000) {
                    return areaDiff;
                }
                return a.centerDistance - b.centerDistance;
            });

        return visibleVideos[0]?.video ?? null;
    }

    function getOrCreateCounter() {
        let counter = document.getElementById(COUNTER_ID);

        if (counter) {
            return counter;
        }

        if (!document.body) {
            return null;
        }

        counter = document.createElement("div");
        counter.id = COUNTER_ID;
        counter.setAttribute("role", "button");
        counter.setAttribute("tabindex", "0");
        counter.title = "Bấm để sửa Views • Chuột phải để khôi phục số thật";

        const icon = document.createElement("span");
        icon.className = "tt-view-counter-icon";
        icon.textContent = "👁";

        const value = document.createElement("span");
        value.id = VALUE_ID;
        value.textContent = "…";

        counter.appendChild(icon);
        counter.appendChild(value);

        counter.addEventListener("click", (event) => {
            event.stopPropagation();
            startEditingCounter();
        });

        counter.addEventListener("keydown", (event) => {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                startEditingCounter();
            }
        });

        counter.addEventListener("contextmenu", (event) => {
            event.preventDefault();
            event.stopPropagation();

            const videoId = getCurrentVideoId();
            if (!videoId) {
                return;
            }

            clearCustomViews(videoId);
            editingVideoId = "";

            const cached = getCachedViews(videoId);
            if (cached !== null) {
                lastRealViews = cached;
                renderCounterValue(counter, cached);
            }

            forceUpdateBurst();
        });

        document.body.appendChild(counter);
        return counter;
    }

    function renderCounterValue(counter, views) {
        if (!counter) {
            return;
        }

        const value = counter.querySelector(`#${VALUE_ID}`);
        if (!value) {
            return;
        }

        value.textContent = formatNumber(views);
        counter.title = "Bấm để sửa Views • Chuột phải để khôi phục số thật";
    }

    function renderLoading(counter) {
        if (!counter || editingVideoId) {
            return;
        }

        const value = counter.querySelector(`#${VALUE_ID}`);
        if (value) {
            value.textContent = "…";
        }
    }

    function startEditingCounter() {
        const videoId = getCurrentVideoId();
        const counter = document.getElementById(COUNTER_ID);

        if (!videoId || !counter || editingVideoId) {
            return;
        }

        const currentCustom = getCustomViews(videoId);
        const currentValue = currentCustom !== null
            ? currentCustom
            : (lastRealViews !== null ? lastRealViews : getCachedViews(videoId));

        if (currentValue === null) {
            return;
        }

        editingVideoId = String(videoId);

        const oldValue = counter.querySelector(`#${VALUE_ID}`);
        if (!oldValue) {
            editingVideoId = "";
            return;
        }

        const input = document.createElement("input");
        input.id = INPUT_ID;
        input.type = "text";
        input.inputMode = "decimal";
        input.autocomplete = "off";
        input.spellcheck = false;
        input.value = String(currentValue);
        input.setAttribute("aria-label", "Sửa số lượt xem");

        oldValue.replaceWith(input);
        counter.classList.add("tt-view-counter-editing");

        input.focus();
        input.select();

        const finish = (save) => {
            if (!editingVideoId) {
                return;
            }

            const editingId = editingVideoId;
            editingVideoId = "";

            if (save) {
                const parsed = parseEditableCount(input.value);
                if (parsed !== null) {
                    setCustomViews(editingId, parsed);
                }
            }

            const replacement = document.createElement("span");
            replacement.id = VALUE_ID;

            if (input.isConnected) {
                input.replaceWith(replacement);
            }

            counter.classList.remove("tt-view-counter-editing");
            updateCounter();
        };

        input.addEventListener("click", (event) => {
            event.stopPropagation();
        });

        input.addEventListener("keydown", (event) => {
            event.stopPropagation();

            if (event.key === "Enter") {
                event.preventDefault();
                finish(true);
            } else if (event.key === "Escape") {
                event.preventDefault();
                finish(false);
            }
        });

        input.addEventListener("blur", () => {
            finish(true);
        }, { once: true });
    }

    function hideCounter() {
        const counter = document.getElementById(COUNTER_ID);
        if (counter) {
            counter.style.display = "none";
        }
    }

    function positionCounter(counter, video) {
        if (!counter || !video) {
            return;
        }

        const rect = video.getBoundingClientRect();

        counter.style.display = "flex";
        counter.style.visibility = "hidden";

        const counterWidth = counter.offsetWidth || 86;
        const top = Math.max(8, rect.top + 12);
        const left = Math.max(
            8,
            Math.min(
                window.innerWidth - counterWidth - 8,
                rect.right - counterWidth - 12
            )
        );

        counter.style.top = `${top}px`;
        counter.style.left = `${left}px`;
        counter.style.visibility = "visible";
    }

    async function updateCounter() {
        const sequence = ++updateSequence;
        const videoId = getCurrentVideoId();
        const video = findActiveVideo();

        if (!videoId) {
            hideCounter();
            return;
        }

        // v1.6: chỉ hiển thị counter khi có video thật trên trang.
        // Không còn tạo thumbnail/preview fallback cho TikTok Shop.
        if (!video) {
            hideCounter();
            return;
        }

        const counter = getOrCreateCounter();
        if (counter) {
            positionCounter(counter, video);

            if (editingVideoId !== String(videoId)) {
                const customNow = getCustomViews(videoId);
                const cachedNow = getCachedViews(videoId);

                if (customNow !== null) {
                    renderCounterValue(counter, customNow);
                } else if (cachedNow !== null) {
                    renderCounterValue(counter, cachedNow);
                } else {
                    renderLoading(counter);
                }
            }
        }

        const views = await getViews(videoId);

        if (sequence !== updateSequence || getCurrentVideoId() !== videoId) {
            return;
        }

        if (views !== null) {
            lastRealViews = views;
            cacheViews(videoId, views);
        }

        const customViews = getCustomViews(videoId);
        const displayViews = customViews !== null
            ? customViews
            : (views !== null ? views : getCachedViews(videoId));

        if (displayViews === null) {
            if (counter) {
                renderLoading(counter);
                positionCounter(counter, anchor);
            }
            return;
        }

        const activeCounter = counter || getOrCreateCounter();
        if (!activeCounter) {
            return;
        }

        if (editingVideoId !== String(videoId)) {
            renderCounterValue(activeCounter, displayViews);
        }

        positionCounter(activeCounter, anchor);
    }

    function scheduleFastUpdate(delay = 60) {
        clearTimeout(mutationTimer);
        mutationTimer = setTimeout(() => {
            updateCounter();
        }, delay);
    }

    function clearRetryTimers() {
        retryTimers.forEach((timer) => clearTimeout(timer));
        retryTimers = [];
    }

    function forceUpdateBurst() {
        clearRetryTimers();
        FAST_RETRY_DELAYS.forEach((delay) => {
            const timer = setTimeout(() => updateCounter(), delay);
            retryTimers.push(timer);
        });
    }

    function onPossibleNavigation() {
        const currentUrl = window.location.href;
        const currentVideoId = getCurrentVideoId() || "";

        if (currentUrl !== lastUrl || currentVideoId !== lastVideoId) {
            lastUrl = currentUrl;
            lastVideoId = currentVideoId;
            updateSequence++;
            editingVideoId = "";
            lastRealViews = null;
            hideCounter();
            forceUpdateBurst();
        }
    }

    const observer = new MutationObserver(() => {
        onPossibleNavigation();
        scheduleFastUpdate();
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ["data-e2e", "aria-label", "src"]
    });

    window.addEventListener("popstate", () => {
        onPossibleNavigation();
        forceUpdateBurst();
    });

    window.addEventListener("hashchange", () => {
        onPossibleNavigation();
        forceUpdateBurst();
    });

    window.addEventListener("pageshow", () => {
        forceUpdateBurst();
    });

    window.addEventListener("focus", () => {
        forceUpdateBurst();
    });

    document.addEventListener("visibilitychange", () => {
        if (!document.hidden) {
            forceUpdateBurst();
        }
    });

    window.addEventListener("resize", () => {
        scheduleFastUpdate(0);
    });

    window.addEventListener(
        "scroll",
        () => scheduleFastUpdate(0),
        { passive: true }
    );

    lastUrl = window.location.href;
    lastVideoId = getCurrentVideoId() || "";

    forceUpdateBurst();

    setInterval(() => {
        onPossibleNavigation();
        updateCounter();
    }, UPDATE_INTERVAL);

    /* ============================================================
     * PROFILE VIDEO FINDER + MULTI-CHANNEL BATCH SCREENSHOT v1.10.1 DEBUG
     * - Paste nhiều URL TikTok, có thể thuộc NHIỀU profile/kênh khác nhau.
     * - Tự tách @username + Video ID, nhóm theo kênh và tự chuyển profile.
     * - Trên mỗi profile: auto scroll, tìm video rồi chụp thumbnail/card có Views.
     * - Trạng thái batch được lưu trong sessionStorage để tiếp tục sau khi chuyển kênh.
     * - Không tạo thumbnail fallback TikTok Shop.
     * ============================================================ */

    const FINDER_BUTTON_ID = "tt-profile-finder-button";
    const FINDER_PANEL_ID = "tt-profile-finder-panel";
    const FINDER_INPUT_ID = "tt-profile-finder-input";
    const FINDER_STATUS_ID = "tt-profile-finder-status";
    const FINDER_RESULTS_ID = "tt-profile-finder-results";
    const FINDER_HIGHLIGHT_CLASS = "tt-profile-finder-highlight";
    const FINDER_BADGE_CLASS = "tt-profile-finder-badge";
    const FINDER_STORAGE_KEY = "tt-profile-finder-last-target-v3";
    const MULTI_BATCH_STATE_KEY = "tt-profile-finder-multichannel-batch-v2";
    const DEBUG_LOG_KEY = "tt-profile-finder-debug-log-v1";
    const DEBUG_LOG_MAX = 2500;
    const DEBUG_VERSION = "1.11.0-sidepanel";

    let finderTargetId = "";
    let finderTimer = null;
    let finderStep = 0;
    let finderNoMoveCount = 0;
    let finderLastScrollY = -1;
    let finderRunning = false;
    let finderHighlighted = null;

    let batchRunning = false;
    let batchCancelled = false;
    let batchTargets = [];
    let batchIndex = 0;
    let batchResults = [];
    let batchCaptureEngagement = false;
    let batchLoadWaitMs = 1400;

    function isTikTokProfilePage_() {
        return /^\/@[^/]+\/?$/i.test(String(location.pathname || ""));
    }

    function extractTargetVideoId_(value) {
        const text = String(value || "").trim();
        if (!text) return "";

        let match = text.match(/\/(?:video|photo)\/(\d{8,})/i);
        if (match) return match[1];

        match = text.match(/[?&](?:item_id|itemId|modal_id)=(\d{8,})/i);
        if (match) return match[1];

        if (/^\d{8,}$/.test(text)) return text;
        return "";
    }

    function extractTargetUsername_(value) {
        const text = String(value || "").trim();
        const match = text.match(/tiktok\.com\/@([^/?#]+)(?:\/|$)/i);
        if (!match) return "";
        try {
            return decodeURIComponent(match[1]).replace(/^@/, "");
        } catch (_) {
            return String(match[1] || "").replace(/^@/, "");
        }
    }

    function getCurrentProfileUsername_() {
        const match = String(location.pathname || "").match(/^\/@([^/]+)\/?$/i);
        if (!match) return "";
        try { return decodeURIComponent(match[1]); } catch (_) { return match[1]; }
    }

    function normalizeUsername_(value) {
        return String(value || "").trim().replace(/^@/, "").toLowerCase();
    }

    function profileUrlForUsername_(username) {
        return `https://www.tiktok.com/@${encodeURIComponent(String(username || "").replace(/^@/, ""))}`;
    }

    function parseFinderTargets_(raw) {
        const seen = new Set();
        const result = [];
        const currentUsername = getCurrentProfileUsername_();

        String(raw || "")
            .split(/\r?\n|\r/)
            .map((line) => line.trim())
            .filter(Boolean)
            .forEach((line) => {
                const id = extractTargetVideoId_(line);
                if (!id || seen.has(id)) return;
                const username = extractTargetUsername_(line) || currentUsername || "";
                seen.add(id);
                result.push({
                    id,
                    username,
                    profileUrl: username ? profileUrlForUsername_(username) : "",
                    raw: line
                });
            });

        return result;
    }

    function groupTargetsByChannel_(targets) {
        const groups = new Map();
        const order = [];
        for (const item of targets) {
            const key = normalizeUsername_(item.username);
            if (!groups.has(key)) {
                groups.set(key, []);
                order.push(key);
            }
            groups.get(key).push(item);
        }
        return order.flatMap((key) => groups.get(key));
    }

    function saveMultiBatchState_(state) {
        try { sessionStorage.setItem(MULTI_BATCH_STATE_KEY, JSON.stringify(state)); } catch (_) {}
    }

    function loadMultiBatchState_() {
        try {
            const raw = sessionStorage.getItem(MULTI_BATCH_STATE_KEY);
            const parsed = raw ? JSON.parse(raw) : null;
            return parsed && typeof parsed === "object" ? parsed : null;
        } catch (_) { return null; }
    }

    function clearMultiBatchState_() {
        try { sessionStorage.removeItem(MULTI_BATCH_STATE_KEY); } catch (_) {}
    }

    function saveFinderTarget_(value) {
        try {
            localStorage.setItem(FINDER_STORAGE_KEY, String(value || ""));
        } catch (_) {}
    }

    function loadFinderTarget_() {
        try {
            return String(localStorage.getItem(FINDER_STORAGE_KEY) || "");
        } catch (_) {
            return "";
        }
    }

    function publishBatchProgress_(message = "", type = "") {
        // Runs only on the TikTok page, never exposes arbitrary page data.
        try {
            chrome.runtime.sendMessage({
                type: "TT_BATCH_PROGRESS",
                payload: {
                    running: batchRunning && !batchCancelled,
                    total: batchTargets.length,
                    index: batchIndex,
                    captureEngagement: batchCaptureEngagement,
                    status: String(message || "").slice(0, 360),
                    statusType: type,
                    results: batchResults.slice(-500),
                    updatedAt: Date.now()
                }
            }, () => void chrome.runtime.lastError);
        } catch (_) {}
    }

    function setFinderStatus_(message, type = "") {
        const el = document.getElementById(FINDER_STATUS_ID);
        if (el) {
            el.textContent = message;
            el.dataset.type = type;
        }
        if (batchRunning || batchTargets.length) publishBatchProgress_(message, type);
    }

    function safeDebugValue_(value, depth = 0) {
        if (depth > 3) return "[depth-limit]";
        if (value == null) return value;
        if (typeof value === "string") return value.length > 1200 ? value.slice(0, 1200) + "…[truncated]" : value;
        if (typeof value === "number" || typeof value === "boolean") return value;
        if (value instanceof Error) {
            return {
                name: value.name,
                message: value.message,
                stack: String(value.stack || "").slice(0, 4000)
            };
        }
        if (value instanceof Element) {
            const r = value.getBoundingClientRect();
            return {
                tag: value.tagName,
                id: value.id || "",
                className: String(value.className || "").slice(0, 300),
                href: String(value.getAttribute?.("href") || "").slice(0, 800),
                rect: {
                    left: Math.round(r.left), top: Math.round(r.top),
                    width: Math.round(r.width), height: Math.round(r.height),
                    right: Math.round(r.right), bottom: Math.round(r.bottom)
                },
                html: String(value.outerHTML || "").slice(0, 1200)
            };
        }
        if (Array.isArray(value)) return value.slice(0, 30).map(v => safeDebugValue_(v, depth + 1));
        if (typeof value === "object") {
            const out = {};
            for (const [k, v] of Object.entries(value).slice(0, 50)) {
                try { out[k] = safeDebugValue_(v, depth + 1); }
                catch (_) { out[k] = "[unserializable]"; }
            }
            return out;
        }
        return String(value);
    }

    function loadDebugLog_() {
        try {
            const raw = sessionStorage.getItem(DEBUG_LOG_KEY);
            const arr = raw ? JSON.parse(raw) : [];
            return Array.isArray(arr) ? arr : [];
        } catch (_) {
            return [];
        }
    }

    function saveDebugLog_(entries) {
        try {
            const trimmed = Array.isArray(entries) ? entries.slice(-DEBUG_LOG_MAX) : [];
            sessionStorage.setItem(DEBUG_LOG_KEY, JSON.stringify(trimmed));
        } catch (_) {}
    }

    function debugLog_(event, data = {}, level = "INFO") {
        try {
            const item = batchTargets?.[batchIndex] || null;
            const state = loadMultiBatchState_() || {};
            const entry = {
                ts: new Date().toISOString(),
                t: Math.round(performance.now()),
                version: DEBUG_VERSION,
                level,
                event,
                pageUrl: location.href,
                pathname: location.pathname,
                visibility: document.visibilityState,
                focused: document.hasFocus(),
                viewport: {
                    innerWidth: window.innerWidth,
                    innerHeight: window.innerHeight,
                    dpr: window.devicePixelRatio,
                    scrollX: Math.round(window.scrollX),
                    scrollY: Math.round(window.scrollY)
                },
                batch: {
                    running: batchRunning,
                    cancelled: batchCancelled,
                    index: batchIndex,
                    total: batchTargets.length,
                    phase: state.phase || "PROFILE",
                    captureEngagement: batchCaptureEngagement,
                    loadWaitMs: batchLoadWaitMs
                },
                target: item ? {
                    id: item.id,
                    username: item.username,
                    raw: item.raw,
                    profileUrl: item.profileUrl
                } : null,
                data: safeDebugValue_(data)
            };

            const log = loadDebugLog_();
            log.push(entry);
            saveDebugLog_(log);
            console.debug("[TT DEBUG]", event, data);
            updateDebugCounter_();
        } catch (err) {
            console.warn("[TT DEBUG] logging failed", err);
        }
    }

    function clearDebugLog_() {
        try { sessionStorage.removeItem(DEBUG_LOG_KEY); } catch (_) {}
        updateDebugCounter_();
    }

    function updateDebugCounter_() {
        const el = document.getElementById("tt-debug-log-count");
        if (!el) return;
        const log = loadDebugLog_();
        const errors = log.filter(x => x.level === "ERROR").length;
        el.textContent = `${log.length} log${errors ? ` • ${errors} lỗi` : ""}`;
    }

    function formatDebugLogText_() {
        const log = loadDebugLog_();
        const header = [
            `TikTok View Counter Debug Log`,
            `Version: ${DEBUG_VERSION}`,
            `Exported: ${new Date().toISOString()}`,
            `Entries: ${log.length}`,
            `User-Agent: ${navigator.userAgent}`,
            `Page: ${location.href}`,
            "=".repeat(90),
            ""
        ].join("\\n");

        const body = log.map((x, idx) => {
            const target = x.target ? `@${x.target.username || "?"} / ${x.target.id || "?"}` : "-";
            const data = JSON.stringify(x.data, null, 2);
            return [
                `#${idx + 1} [${x.ts}] ${x.level} ${x.event}`,
                `Target: ${target}`,
                `Phase: ${x.batch?.phase} | Index: ${(x.batch?.index ?? 0) + 1}/${x.batch?.total ?? 0}`,
                `URL: ${x.pageUrl}`,
                `Viewport: ${JSON.stringify(x.viewport)}`,
                `Data: ${data}`,
                "-".repeat(90)
            ].join("\\n");
        }).join("\\n");

        return header + body;
    }

    async function downloadDebugLog_() {
        const log = loadDebugLog_();
        if (!log.length) {
            setFinderStatus_("Chưa có Debug Log để tải.", "error");
            return;
        }

        debugLog_("LOG_EXPORT_REQUEST", { entries: log.length });

        const d = new Date();
        const pad = (n, len = 2) => String(n).padStart(len, "0");
        const stamp = `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;

        const txt = formatDebugLogText_();
        const json = JSON.stringify({
            version: DEBUG_VERSION,
            exportedAt: new Date().toISOString(),
            userAgent: navigator.userAgent,
            page: location.href,
            entries: loadDebugLog_()
        }, null, 2);

        const result = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
                type: "TT_DOWNLOAD_DEBUG_LOG",
                txt,
                json,
                baseName: `TikTok_Debug_${stamp}`
            }, (res) => {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                if (!res?.ok) return reject(new Error(res?.error || "Không tải được Debug Log."));
                resolve(res);
            });
        });

        setFinderStatus_(`Đã tải Debug Log: ${result.txtFilename || "TXT"} + JSON`, "success");
    }

    function renderBatchResults_() {
        const box = document.getElementById(FINDER_RESULTS_ID);
        if (!box) return;

        if (!batchTargets.length) {
            box.innerHTML = "";
            box.style.display = "none";
            return;
        }

        box.style.display = "block";
        box.innerHTML = batchTargets.map((item, index) => {
            const result = batchResults.find((x) => x.id === item.id);
            let status = "WAITING";
            let label = "Chờ";
            let icon = "○";

            if (batchRunning && index === batchIndex && !result) {
                status = "SEARCHING";
                label = "Đang tìm";
                icon = "…";
            } else if (result?.status === "SAVED") {
                status = "SAVED";
                label = result?.engagementFilename ? "Đã lưu + tương tác" : "Đã tìm + đã lưu";
                icon = "✓";
            } else if (result?.status === "NOT FOUND") {
                status = "NOT_FOUND";
                label = "Không tìm thấy";
                icon = "×";
            } else if (result?.status === "ERROR") {
                status = "ERROR";
                label = "Tìm thấy nhưng lỗi chụp";
                icon = "!";
            }

            const safeRaw = String(item.raw || item.id)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;");

            const errorText = result?.error || result?.engagementError || "";
            const safeError = String(errorText)
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;");

            return `<div class="tt-batch-result-row" data-status="${status}">
                <span class="tt-batch-result-icon">${icon}</span>
                <span class="tt-batch-result-main">
                    <span class="tt-batch-result-label">${index + 1}. ${label}${item.username ? ` • @${item.username}` : ""}</span>
                    <span class="tt-batch-result-link" title="${safeRaw}">${safeRaw}</span>
                    ${safeError ? `<span class="tt-batch-result-error" title="${safeError}">Lỗi: ${safeError}</span>` : ""}
                </span>
            </div>`;
        }).join("");
    }

    function setBatchResult_(item, result) {
        const existingIndex = batchResults.findIndex((x) => x.id === item.id);
        if (existingIndex >= 0) batchResults[existingIndex] = result;
        else batchResults.push(result);
        debugLog_("BATCH_RESULT", { item, result }, result?.status === "ERROR" ? "ERROR" : "INFO");
        renderBatchResults_();
        publishBatchProgress_();
    }

    function sleep_(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
    }

    function clearFinderHighlight_() {
        if (finderHighlighted && finderHighlighted.isConnected) {
            finderHighlighted.classList.remove(FINDER_HIGHLIGHT_CLASS);
            finderHighlighted.classList.remove("tt-profile-finder-pulse");
            const badge = finderHighlighted.querySelector(`.${FINDER_BADGE_CLASS}`);
            if (badge) badge.remove();

            if (finderHighlighted.dataset.ttFinderPrevPosition === "static") {
                finderHighlighted.style.position = "";
                delete finderHighlighted.dataset.ttFinderPrevPosition;
            }
        }
        finderHighlighted = null;
        updateFinderButtons_();
    }

    function findVideoAnchorById_(videoId) {
        if (!videoId) return null;

        const anchors = document.querySelectorAll('a[href*="/video/"], a[href*="/photo/"]');
        for (const anchor of anchors) {
            const href = String(anchor.getAttribute("href") || anchor.href || "");
            const id = extractTargetVideoId_(href);
            if (id === String(videoId)) return anchor;
        }
        return null;
    }

    function getHighlightTarget_(anchor) {
        if (!anchor) return null;
        return anchor.closest('[data-e2e*="user-post-item"], [data-e2e*="post-item"], div[class*="DivItemContainer"], div[class*="DivVideoFeed"]') || anchor;
    }

    function getScreenshotTarget_(anchor) {
        if (!anchor) return null;

        // Ưu tiên chính anchor thumbnail vì phần Views trên profile thường nằm bên trong anchor.
        // Nếu anchor quá nhỏ thì dùng card gần nhất.
        const rect = anchor.getBoundingClientRect();
        if (rect.width >= 120 && rect.height >= 120) return anchor;
        return getHighlightTarget_(anchor) || anchor;
    }

    function highlightFoundVideo_(anchor) {
        clearFinderHighlight_();

        const target = getHighlightTarget_(anchor);
        if (!target) return;

        finderHighlighted = target;
        target.classList.add(FINDER_HIGHLIGHT_CLASS);

        const computed = getComputedStyle(target);
        if (computed.position === "static") {
            target.dataset.ttFinderPrevPosition = "static";
            target.style.position = "relative";
        }

        const badge = document.createElement("div");
        badge.className = FINDER_BADGE_CLASS;
        badge.textContent = "VIDEO CẦN TÌM";
        target.appendChild(badge);

        target.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });

        setTimeout(() => {
            if (target && target.isConnected) {
                target.classList.add("tt-profile-finder-pulse");
                setTimeout(() => target.classList.remove("tt-profile-finder-pulse"), 1800);
            }
        }, 450);
    }

    function stopFinder_(message = "Đã dừng.", type = "") {
        finderRunning = false;
        if (finderTimer) {
            clearTimeout(finderTimer);
            finderTimer = null;
        }
        setFinderStatus_(message, type);
        updateFinderButtons_();
    }

    function finderTick_() {
        if (!finderRunning || !finderTargetId || batchRunning) return;

        const found = findVideoAnchorById_(finderTargetId);
        if (found) {
            highlightFoundVideo_(found);
            stopFinder_(`Đã tìm thấy Video ID ${finderTargetId}.`, "success");
            return;
        }

        finderStep += 1;
        const before = window.scrollY;
        const stepSize = Math.max(560, Math.floor(window.innerHeight * 0.82));
        window.scrollBy({ top: stepSize, left: 0, behavior: "smooth" });

        setFinderStatus_(`Đang tìm ${finderTargetId}… • lượt ${finderStep}`, "searching");

        finderTimer = setTimeout(() => {
            const after = window.scrollY;
            if (Math.abs(after - before) < 8 || after === finderLastScrollY) finderNoMoveCount += 1;
            else finderNoMoveCount = 0;

            finderLastScrollY = after;

            if (finderNoMoveCount >= 7 || finderStep >= 220) {
                stopFinder_("Không tìm thấy video trên profile.", "error");
                return;
            }

            finderTick_();
        }, 900);
    }

    function startFinder_() {
        if (batchRunning) return;

        const input = document.getElementById(FINDER_INPUT_ID);
        const targets = parseFinderTargets_(input ? input.value : "");
        const first = targets[0];

        clearFinderHighlight_();

        if (!first) {
            stopFinder_("Hãy nhập ít nhất 1 Link/Video ID hợp lệ.", "error");
            return;
        }

        if (!isTikTokProfilePage_()) {
            stopFinder_("Hãy mở trang profile KOL rồi bấm Tìm.", "error");
            return;
        }

        finderTargetId = first.id;
        saveFinderTarget_(input ? input.value : first.raw);
        finderStep = 0;
        finderNoMoveCount = 0;
        finderLastScrollY = window.scrollY;
        finderRunning = true;
        updateFinderButtons_();

        const already = findVideoAnchorById_(finderTargetId);
        if (already) {
            highlightFoundVideo_(already);
            stopFinder_(`Đã tìm thấy Video ID ${finderTargetId}.`, "success");
            return;
        }

        setFinderStatus_(`Đang tìm ${finderTargetId}…`, "searching");
        finderTick_();
    }

    async function findVideoForBatch_(videoId) {
        const existing = findVideoAnchorById_(videoId);
        if (existing) return existing;

        let noMove = 0;
        let lastY = window.scrollY;

        for (let step = 1; step <= 240; step++) {
            if (!batchRunning || batchCancelled) return null;

            const found = findVideoAnchorById_(videoId);
            if (found) return found;

            setFinderStatus_(`Batch ${batchIndex + 1}/${batchTargets.length}: đang tìm ${videoId} • lượt ${step}`, "searching");

            const before = window.scrollY;
            const stepSize = Math.max(520, Math.floor(window.innerHeight * 0.78));
            window.scrollBy({ top: stepSize, left: 0, behavior: "smooth" });
            await sleep_(850);

            const after = window.scrollY;
            if (Math.abs(after - before) < 8 || after === lastY) noMove += 1;
            else noMove = 0;
            lastY = after;

            // Ở cuối trang chờ lazy-load thêm một ít rồi kết luận.
            if (noMove >= 8) break;
        }

        return findVideoAnchorById_(videoId);
    }

    async function waitForThumbnailReady_(anchor, timeoutMs = 12000) {
        if (!anchor) {
            debugLog_("THUMB_WAIT_NO_ANCHOR", {}, "ERROR");
            return false;
        }

        const started = Date.now();
        debugLog_("THUMB_WAIT_START", { timeoutMs, anchor });
        let stableRounds = 0;
        let lastSignature = "";

        while (Date.now() - started < timeoutMs) {
            if (!batchRunning || batchCancelled) return false;

            const rect = anchor.getBoundingClientRect();
            const imgs = Array.from(anchor.querySelectorAll("img"));
            const videos = Array.from(anchor.querySelectorAll("video"));

            // TikTok thumbnails may be <img> or a video/poster depending on build.
            let mediaReady = false;

            for (const img of imgs) {
                try {
                    if (img.complete && img.naturalWidth >= 120 && img.naturalHeight >= 120) {
                        if (typeof img.decode === "function") {
                            try { await img.decode(); } catch (_) {}
                        }
                        mediaReady = true;
                        break;
                    }
                } catch (_) {}
            }

            if (!mediaReady) {
                for (const video of videos) {
                    try {
                        if (video.readyState >= 2 && video.videoWidth >= 120 && video.videoHeight >= 120) {
                            mediaReady = true;
                            break;
                        }
                    } catch (_) {}
                }
            }

            // Some TikTok builds use background-image instead of <img>.
            if (!mediaReady) {
                const candidates = [anchor, ...Array.from(anchor.querySelectorAll("div"))].slice(0, 25);
                mediaReady = candidates.some((el) => {
                    try {
                        const bg = getComputedStyle(el).backgroundImage || "";
                        return bg && bg !== "none" && /url\(/i.test(bg);
                    } catch (_) {
                        return false;
                    }
                });
            }

            const signature = `${Math.round(rect.width)}x${Math.round(rect.height)}:${Math.round(rect.top)}:${imgs.map(i => `${i.naturalWidth}x${i.naturalHeight}:${i.complete}`).join("|")}`;
            if (signature === lastSignature && mediaReady && rect.width >= 120 && rect.height >= 120) {
                stableRounds += 1;
            } else {
                stableRounds = 0;
                lastSignature = signature;
            }

            // Require several stable checks so screenshot isn't taken while lazy image is still swapping in.
            if (stableRounds >= 3) {
                debugLog_("THUMB_WAIT_READY", {
                    elapsedMs: Date.now() - started,
                    stableRounds,
                    mediaReady,
                    rect,
                    imageCount: imgs.length,
                    images: imgs.slice(0, 8).map(i => ({
                        complete: i.complete,
                        naturalWidth: i.naturalWidth,
                        naturalHeight: i.naturalHeight,
                        src: String(i.currentSrc || i.src || "").slice(0, 500)
                    })),
                    videoCount: videos.length
                });
                await sleep_(batchLoadWaitMs);
                return true;
            }

            await sleep_(300);
        }

        // Timeout is not fatal; caller can still attempt capture, but log it.
        debugLog_("THUMB_WAIT_TIMEOUT", {
            elapsedMs: Date.now() - started,
            anchor,
            timeoutMs
        }, "WARN");
        return false;
    }

    function isCurrentVideoPage_(videoId) {
        const currentId = extractTargetVideoId_(location.href);
        return !!currentId && String(currentId) === String(videoId);
    }

    async function waitForEngagementReady_(videoId, timeoutMs = 15000) {
        const started = Date.now();
        let stable = 0;
        let last = "";

        while (Date.now() - started < timeoutMs) {
            if (!batchRunning || batchCancelled) return null;
            if (!isCurrentVideoPage_(videoId)) {
                await sleep_(300);
                continue;
            }

            const result = (() => {
                const vw = innerWidth, vh = innerHeight;
                const buttons = Array.from(document.querySelectorAll(
                    'button,[role="button"],[data-e2e],[aria-label]'
                )).filter((el) => {
                    if (el.closest(`#${FINDER_PANEL_ID}`) || el.closest(`#${FINDER_BUTTON_ID}`)) return false;
                    const r = el.getBoundingClientRect();
                    if (r.width < 20 || r.height < 20 || r.bottom <= 0 || r.top >= vh) return false;
                    const txt = [
                        el.getAttribute("data-e2e") || "",
                        el.getAttribute("aria-label") || "",
                        el.innerText || ""
                    ].join(" ").toLowerCase();
                    return /like|comment|share|favorite|bookmark|thích|bình luận|chia sẻ/.test(txt);
                });

                if (buttons.length < 2) return null;

                // The Views overlay is positioned over the actual TikTok video.
                // Wait for the displayed number before saving evidence.
                const counter = document.getElementById(COUNTER_ID);
                const valueEl = document.getElementById(VALUE_ID);
                const counterRect = counter?.getBoundingClientRect();
                const counterReady = counter && counter.getClientRects().length &&
                    counterRect.width > 25 && counterRect.height > 15 &&
                    valueEl?.textContent?.trim() && !/[.…]/.test(valueEl.textContent);
                const video = findActiveVideo();
                if (!counterReady || !video) return null;
                const videoRect = video.getBoundingClientRect();
                if (videoRect.width < 100 || videoRect.height < 100) return null;

                const rects = [...buttons.map(b => b.getBoundingClientRect()), counterRect, videoRect];
                // Crop a single image containing Views + video + the engagement column.
                const left = Math.max(0, Math.floor(Math.min(...rects.map(r => r.left)) - 14));
                const top = Math.max(0, Math.floor(Math.min(...rects.map(r => r.top)) - 15));
                const right = Math.min(vw, Math.ceil(Math.max(...rects.map(r => r.right)) + 18));
                const bottom = Math.min(vh, Math.ceil(Math.max(...rects.map(r => r.bottom)) + 18));
                if (right - left < 260 || bottom - top < 180) return null;

                return {
                    left, top, right, bottom,
                    signature: `${valueEl.textContent.trim()}|` + buttons.map((b) =>
                        (b.innerText || b.getAttribute("aria-label") || "").trim()).join("|")
                };
            })();

            if (!result) {
                await sleep_(350);
                continue;
            }

            if (result.signature === last) stable += 1;
            else {
                last = result.signature;
                stable = 0;
            }

            if (stable >= 3) {
                await sleep_(900);
                return result;
            }

            await sleep_(350);
        }

        return null;
    }

    async function captureVisibleCrop_(left, top, right, bottom, filename) {
        const response = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ type: "TT_CAPTURE_VISIBLE_TAB" }, (res) => {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                if (!res || !res.ok || !res.dataUrl) return reject(new Error(res?.error || "Không chụp được tab hiện tại."));
                resolve(res);
            });
        });

        const image = new Image();
        image.src = response.dataUrl;
        await new Promise((resolve, reject) => {
            image.onload = resolve;
            image.onerror = () => reject(new Error("Không đọc được ảnh screenshot."));
        });

        const scaleX = image.naturalWidth / window.innerWidth;
        const scaleY = image.naturalHeight / window.innerHeight;
        const sx = Math.max(0, Math.round(left * scaleX));
        const sy = Math.max(0, Math.round(top * scaleY));
        const sw = Math.max(1, Math.round((right - left) * scaleX));
        const sh = Math.max(1, Math.round((bottom - top) * scaleY));

        const canvas = document.createElement("canvas");
        canvas.width = sw;
        canvas.height = sh;
        const ctx = canvas.getContext("2d");
        if (!ctx) throw new Error("Không tạo được canvas crop.");
        ctx.drawImage(image, sx, sy, sw, sh, 0, 0, sw, sh);

        const dataUrl = canvas.toDataURL("image/jpeg", 0.88);
        return await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
                type: "TT_DOWNLOAD_SCREENSHOT",
                dataUrl,
                filename
            }, (res) => {
                if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
                if (!res || !res.ok) return reject(new Error(res?.error || "Không lưu được screenshot."));
                resolve(res);
            });
        });
    }

    async function captureEngagementPage_(videoId, username = "") {
        const box = await waitForEngagementReady_(videoId);
        if (!box) throw new Error("Phần Like/Comment chưa load đủ.");

        const d = new Date();
        const pad = (n, len = 2) => String(n).padStart(len, "0");
        const stamp = `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}_${pad(d.getMilliseconds(),3)}`;
        const userPart = String(username || "").replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "-");
        const filename = `Screenshot/${[stamp, userPart, videoId, "engagement"].filter(Boolean).join("_")}.jpg`;

        const saved = await captureVisibleCrop_(box.left, box.top, box.right, box.bottom, filename);
        return {
            filename: saved.actualFilename || saved.requestedFilename || filename,
            downloadId: saved.downloadId
        };
    }

    function timestampFileName_(videoId = "", username = "") {
        const d = new Date();
        const pad = (n, len = 2) => String(n).padStart(len, "0");
        const stamp = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}_${pad(d.getMilliseconds(), 3)}`;
        const idPart = String(videoId || "").replace(/[^0-9]/g, "");
        const userPart = String(username || "").replace(/^@/, "").replace(/[^a-zA-Z0-9._-]/g, "-");
        return [stamp, userPart, idPart].filter(Boolean).join("_") + ".jpg";
    }

    function isScrollableCandidate_(el) {
        if (!el || el === document.body) return false;
        try {
            const st = getComputedStyle(el);
            return /(auto|scroll|overlay)/i.test(st.overflowY || "") &&
                el.scrollHeight > el.clientHeight + 40 &&
                el.clientHeight > 180;
        } catch (_) {
            return false;
        }
    }

    function collectScrollCandidates_(target) {
        const result = [];
        const seen = new Set();

        const add = (el, score) => {
            if (!el || seen.has(el)) return;
            seen.add(el);
            result.push({ el, score });
        };

        // Direct ancestors first.
        let p = target?.parentElement;
        let depth = 0;
        while (p && depth < 15) {
            if (isScrollableCandidate_(p)) add(p, 2000 - depth * 30);
            p = p.parentElement;
            depth++;
        }

        // Then visible page-level scroll containers.
        for (const el of document.querySelectorAll("main, [data-e2e], div")) {
            if (!isScrollableCandidate_(el)) continue;
            const r = el.getBoundingClientRect();
            if (r.width < 280 || r.height < 280) continue;

            let score = Math.min((r.width * r.height) / 10000, 500);
            if (el.contains(target)) score += 1000;
            if (r.top <= 120 && r.bottom >= window.innerHeight * 0.7) score += 150;
            add(el, score);
        }

        add(document.scrollingElement || document.documentElement, 50);

        return result.sort((a, b) => b.score - a.score).map(x => x.el);
    }

    function targetFullyVisible_(target, marginTop = 70, marginBottom = 45) {
        if (!target || !target.isConnected) return false;
        const r = target.getBoundingClientRect();

        return (
            r.width >= 80 &&
            r.height >= 80 &&
            r.left >= 0 &&
            r.right <= window.innerWidth &&
            r.top >= marginTop &&
            r.bottom <= window.innerHeight - marginBottom
        );
    }

    async function moveScrollerAndMeasure_(scroller, target, delta, videoId = "") {
        if (!scroller || !target?.isConnected) return false;

        const beforeRect = target.getBoundingClientRect();
        let beforeScroll = 0;

        try {
            beforeScroll = Number(scroller.scrollTop || 0);
            scroller.scrollTop = beforeScroll + delta;
        } catch (_) {
            return false;
        }

        await sleep_(140);

        const afterRect = target.getBoundingClientRect();
        const movement = beforeRect.top - afterRect.top;

        debugLog_("SCROLLER_PROBE", {
            videoId,
            scroller: {
                tag: scroller.tagName,
                className: String(scroller.className || "").slice(0, 220),
                beforeScroll,
                afterScroll: Number(scroller.scrollTop || 0)
            },
            delta,
            beforeTop: beforeRect.top,
            afterTop: afterRect.top,
            targetMovement: movement
        });

        return Math.abs(movement) >= 8;
    }

    async function bringTargetFullyVisible_(target, videoId = "") {
        if (!target || !target.isConnected) return false;

        const desiredTop = Math.max(105, Math.min(165, window.innerHeight * 0.18));

        debugLog_("BRING_VISIBLE_START", {
            videoId,
            rect: target.getBoundingClientRect(),
            viewport: { width: innerWidth, height: innerHeight }
        });

        // IMPORTANT: no smooth animation.
        try {
            target.scrollIntoView({ behavior: "auto", block: "center", inline: "nearest" });
        } catch (_) {}
        await sleep_(220);

        if (targetFullyVisible_(target)) {
            debugLog_("BRING_VISIBLE_NATIVE_OK", { videoId, rect: target.getBoundingClientRect() });
            return true;
        }

        const candidates = collectScrollCandidates_(target);
        let chosen = null;

        // Identify the exact TikTok container that moves this tile.
        for (const scroller of candidates) {
            if (!target.isConnected) return false;

            const r = target.getBoundingClientRect();
            const delta = r.top - desiredTop;
            if (Math.abs(delta) < 8) continue;

            if (await moveScrollerAndMeasure_(scroller, target, delta, videoId)) {
                chosen = scroller;
                debugLog_("SCROLLER_SELECTED", {
                    videoId,
                    tag: scroller.tagName,
                    className: String(scroller.className || "").slice(0, 250),
                    rect: target.getBoundingClientRect()
                });
                break;
            }
        }

        // Precise positioning using the discovered scroller.
        if (chosen) {
            for (let i = 0; i < 12 && !targetFullyVisible_(target); i++) {
                const r = target.getBoundingClientRect();

                let delta = r.top - desiredTop;
                if (r.bottom > window.innerHeight - 45) {
                    delta = Math.max(delta, r.bottom - (window.innerHeight - 100));
                }

                try { chosen.scrollTop += delta; } catch (_) {}
                await sleep_(150);

                debugLog_("SCROLLER_POSITION", {
                    videoId,
                    step: i,
                    delta,
                    scrollTop: Number(chosen.scrollTop || 0),
                    rect: target.getBoundingClientRect()
                });
            }
        } else {
            // Last fallback. Direct window/document movement, verified after every step.
            for (let i = 0; i < 8 && !targetFullyVisible_(target); i++) {
                const r = target.getBoundingClientRect();
                let delta = r.top - desiredTop;
                if (r.bottom > window.innerHeight - 45) {
                    delta = Math.max(delta, r.bottom - (window.innerHeight - 100));
                }

                const beforeTop = r.top;
                try { window.scrollBy({ top: delta, left: 0, behavior: "auto" }); }
                catch (_) { window.scrollBy(0, delta); }
                await sleep_(150);

                const afterTop = target.getBoundingClientRect().top;
                debugLog_("WINDOW_POSITION", {
                    videoId, step: i, delta, beforeTop, afterTop, scrollY: window.scrollY
                });

                // documentElement fallback
                if (Math.abs(afterTop - beforeTop) < 5) {
                    const doc = document.scrollingElement || document.documentElement;
                    try { doc.scrollTop += delta; } catch (_) {}
                    await sleep_(150);
                }
            }
        }

        const ok = targetFullyVisible_(target);
        debugLog_("BRING_VISIBLE_END", {
            videoId,
            ok,
            rect: target.getBoundingClientRect()
        }, ok ? "INFO" : "ERROR");

        return ok;
    }

    async function waitFullyVisibleStable_(target, videoId = "", timeoutMs = 8000) {
        const started = Date.now();
        let stable = 0;
        let last = "";

        while (Date.now() - started < timeoutMs) {
            if (!target?.isConnected) return false;

            if (!targetFullyVisible_(target)) {
                stable = 0;
                await bringTargetFullyVisible_(target, videoId);
                await sleep_(200);
                continue;
            }

            const r = target.getBoundingClientRect();
            const sig = `${Math.round(r.left)}:${Math.round(r.top)}:${Math.round(r.width)}:${Math.round(r.height)}`;

            if (sig === last) stable += 1;
            else {
                last = sig;
                stable = 0;
            }

            if (stable >= 3) {
                debugLog_("VISIBLE_STABLE_OK", {
                    videoId,
                    elapsedMs: Date.now() - started,
                    rect: r
                });
                return true;
            }

            await sleep_(200);
        }

        debugLog_("VISIBLE_STABLE_TIMEOUT", {
            videoId,
            rect: target?.getBoundingClientRect?.()
        }, "ERROR");
        return false;
    }

    async function captureThumbnail_(anchor, videoId, username = "") {
        debugLog_("CAPTURE_THUMB_START", { videoId, username, anchor });

        let currentAnchor = anchor;
        let target = getScreenshotTarget_(currentAnchor);

        if (!target) {
            debugLog_("CAPTURE_TARGET_NOT_FOUND", { videoId, username, anchor }, "ERROR");
            throw new Error("Không xác định được thumbnail để chụp.");
        }

        debugLog_("CAPTURE_TARGET_FOUND", { videoId, username, target });

        // A. FIRST position the whole video tile in viewport.
        setFinderStatus_(`Đã tìm thấy ${videoId}. Đang kéo VDO hiện đầy đủ trước khi chụp…`, "searching");
        let visibleOk = await bringTargetFullyVisible_(target, videoId);

        if (!visibleOk) {
            // TikTok may have replaced DOM nodes while scrolling.
            currentAnchor = findVideoAnchorById_(videoId) || currentAnchor;
            target = getScreenshotTarget_(currentAnchor) || target;
            visibleOk = await bringTargetFullyVisible_(target, videoId);
        }

        if (!visibleOk) {
            throw new Error("Không kéo được VDO vào đầy đủ màn hình.");
        }

        // B. Wait until actual thumbnail/media has loaded.
        setFinderStatus_(`VDO đã hiện đủ. Đang chờ thumbnail load hoàn tất…`, "searching");
        const thumbReady = await waitForThumbnailReady_(currentAnchor, 12000);
        debugLog_("CAPTURE_AFTER_WAIT", { videoId, thumbReady, target, currentAnchor });

        // C. Loading may shift the grid. Re-find + reposition again.
        currentAnchor = findVideoAnchorById_(videoId) || currentAnchor;
        target = getScreenshotTarget_(currentAnchor) || target;

        setFinderStatus_(`Thumbnail đã load. Đang khóa vị trí VDO…`, "searching");
        visibleOk = await bringTargetFullyVisible_(target, videoId);
        if (!visibleOk) {
            throw new Error("Thumbnail load xong nhưng VDO vẫn chưa hiện đầy đủ.");
        }

        // D. Must be stable for several checks.
        const stableVisible = await waitFullyVisibleStable_(target, videoId, 8000);
        if (!stableVisible) {
            throw new Error("VDO chưa đứng yên hoàn toàn trong vùng chụp.");
        }

        // Clean screenshot.
        clearFinderHighlight_();
        await sleep_(250);

        // E. HARD GATE: do NOT screenshot if any part is clipped.
        if (!targetFullyVisible_(target, 55, 35)) {
            debugLog_("FINAL_VISIBILITY_GATE_FAILED", {
                videoId,
                rect: target.getBoundingClientRect(),
                viewport: { width: innerWidth, height: innerHeight }
            }, "ERROR");
            throw new Error("Dừng chụp: VDO chưa hiển thị 100%.");
        }

        const rect = target.getBoundingClientRect();
        const left = Math.max(0, rect.left);
        const top = Math.max(0, rect.top);
        const right = Math.min(window.innerWidth, rect.right);
        const bottom = Math.min(window.innerHeight, rect.bottom);
        const width = right - left;
        const height = bottom - top;

        debugLog_("CAPTURE_RECT_FINAL", {
            videoId,
            rect,
            clipped: { left, top, right, bottom, width, height },
            targetConnected: target.isConnected,
            anchorConnected: currentAnchor.isConnected
        });

        // Require almost the full DOM rectangle, not merely an 80px sliver.
        if (
            width < rect.width - 3 ||
            height < rect.height - 3 ||
            width < 80 ||
            height < 80
        ) {
            throw new Error(
                `Không chụp: VDO còn bị cắt (${Math.round(width)}x${Math.round(height)} / ${Math.round(rect.width)}x${Math.round(rect.height)}).`
            );
        }

        const response = await new Promise((resolve, reject) => {
            try {
                chrome.runtime.sendMessage({ type: "TT_CAPTURE_VISIBLE_TAB" }, (res) => {
                    if (chrome.runtime.lastError) {
                        debugLog_("CAPTURE_VISIBLE_RUNTIME_ERROR", {
                            message: chrome.runtime.lastError.message
                        }, "ERROR");
                        reject(new Error(chrome.runtime.lastError.message));
                        return;
                    }
                    if (!res || !res.ok || !res.dataUrl) {
                        debugLog_("CAPTURE_VISIBLE_FAILED", { response: res }, "ERROR");
                        reject(new Error(res?.error || "Không chụp được tab hiện tại."));
                        return;
                    }
                    debugLog_("CAPTURE_VISIBLE_OK", {
                        dataUrlLength: res.dataUrl.length,
                        responseMeta: { ok: res.ok, windowId: res.windowId, tabId: res.tabId }
                    });
                    resolve(res);
                });
            } catch (error) {
                reject(error);
            }
        });

        const image = new Image();
        image.src = response.dataUrl;
        await new Promise((resolve, reject) => {
            image.onload = resolve;
            image.onerror = () => reject(new Error("Không đọc được ảnh screenshot."));
        });

        const scaleX = image.naturalWidth / window.innerWidth;
        const scaleY = image.naturalHeight / window.innerHeight;
        debugLog_("CAPTURE_SOURCE_IMAGE", {
            naturalWidth: image.naturalWidth,
            naturalHeight: image.naturalHeight,
            innerWidth: window.innerWidth,
            innerHeight: window.innerHeight,
            scaleX,
            scaleY
        });

        const sx = Math.max(0, Math.round(left * scaleX));
        const sy = Math.max(0, Math.round(top * scaleY));
        const sw = Math.max(1, Math.round(width * scaleX));
        const sh = Math.max(1, Math.round(height * scaleY));

        const canvas = document.createElement("canvas");
        canvas.width = sw;
        canvas.height = sh;
        const ctx = canvas.getContext("2d");
        if (!ctx) throw new Error("Không tạo được canvas crop.");

        ctx.drawImage(image, sx, sy, sw, sh, 0, 0, sw, sh);
        const croppedDataUrl = canvas.toDataURL("image/jpeg", 0.90);
        const filename = `Screenshot/${timestampFileName_(videoId, username)}`;

        debugLog_("CAPTURE_CROP_READY", {
            videoId,
            cropSource: { sx, sy, sw, sh },
            canvas: { width: canvas.width, height: canvas.height },
            jpegDataLength: croppedDataUrl.length,
            filename
        });

        const downloadResult = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({
                type: "TT_DOWNLOAD_SCREENSHOT",
                dataUrl: croppedDataUrl,
                filename,
                videoId
            }, (res) => {
                if (chrome.runtime.lastError) {
                    debugLog_("DOWNLOAD_RUNTIME_ERROR", {
                        filename,
                        message: chrome.runtime.lastError.message
                    }, "ERROR");
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }
                if (!res || !res.ok) {
                    debugLog_("DOWNLOAD_FAILED", { filename, response: res }, "ERROR");
                    reject(new Error(res?.error || "Không lưu được screenshot."));
                    return;
                }
                debugLog_("DOWNLOAD_OK", {
                    filename,
                    requestedFilename: res.requestedFilename,
                    actualFilename: res.actualFilename,
                    downloadId: res.downloadId
                });
                resolve(res);
            });
        });

        const finalResult = {
            filename: downloadResult.actualFilename || downloadResult.requestedFilename || filename,
            downloadId: downloadResult.downloadId
        };
        debugLog_("CAPTURE_THUMB_SUCCESS", { videoId, username, finalResult });
        return finalResult;
    }

    function setBatchPanelCompact_(enabled) {
        const panel = document.getElementById(FINDER_PANEL_ID);
        if (!panel) return;
        panel.classList.toggle("tt-batch-compact", !!enabled);
    }

    function buildBatchState_(targets, rawInput) {
        return {
            version: 1,
            running: true,
            createdAt: Date.now(),
            rawInput: String(rawInput || ""),
            targets: groupTargetsByChannel_(targets),
            index: 0,
            results: [],
            phase: "PROFILE",
            captureEngagement: !!document.querySelector('[data-option="engagement"]')?.checked,
            loadWaitMs: Math.max(500, Number(document.querySelector('[data-option="load-wait"]')?.value || 1400))
        };
    }

    function applyBatchStateToMemory_(state) {
        batchTargets = Array.isArray(state?.targets) ? state.targets : [];
        batchIndex = Math.max(0, Number(state?.index || 0));
        batchResults = Array.isArray(state?.results) ? state.results : [];
        batchCaptureEngagement = !!state?.captureEngagement;
        batchLoadWaitMs = Math.max(500, Number(state?.loadWaitMs || 1400));
        batchRunning = !!state?.running;
        batchCancelled = !batchRunning;
    }

    function persistCurrentBatch_() {
        saveMultiBatchState_({
            version: 1,
            running: batchRunning && !batchCancelled,
            createdAt: Date.now(),
            rawInput: document.getElementById(FINDER_INPUT_ID)?.value || "",
            targets: batchTargets,
            index: batchIndex,
            results: batchResults,
            phase: loadMultiBatchState_()?.phase || "PROFILE",
            captureEngagement: batchCaptureEngagement,
            loadWaitMs: batchLoadWaitMs
        });
    }

    async function processCurrentBatchTarget_() {
        const item = batchTargets[batchIndex];
        if (!item) return "DONE";

        const persisted = loadMultiBatchState_() || {};
        const phase = batchCaptureEngagement ? "ENGAGEMENT" : (persisted.phase || "PROFILE");
        debugLog_("TARGET_PROCESS_START", {
            item,
            phase,
            currentProfile: getCurrentProfileUsername_(),
            isProfilePage: isTikTokProfilePage_()
        });

        // Phase 2: after navigating directly to the video, capture interaction controls.
        if (phase === "ENGAGEMENT") {
            if (!isCurrentVideoPage_(item.id)) {
                setFinderStatus_(`Đang mở VDO ${item.id} để chụp Like/Comment…`, "searching");
                persistCurrentBatch_();
                const state = loadMultiBatchState_() || {};
                state.phase = "ENGAGEMENT";
                saveMultiBatchState_(state);
                location.assign(`https://www.tiktok.com/@${encodeURIComponent(item.username)}/${/\/photo\//i.test(item.raw) ? "photo" : "video"}/${item.id}`);
                return "NAVIGATE";
            }

            try {
                setFinderStatus_(`VDO ${item.id}: chờ Like/Comment load đầy đủ…`, "searching");
                const eng = await captureEngagementPage_(item.id, item.username);
                const old = batchResults.find((x) => x.id === item.id) || {};
                setBatchResult_(item, {
                    ...old,
                    id: item.id,
                    username: item.username,
                    status: "SAVED",
                    engagementFilename: eng.filename,
                    raw: item.raw
                });
                setFinderStatus_(`Đã chụp Like/Comment: ${eng.filename}`, "success");
            } catch (error) {
                debugLog_("CAPTURE_ENGAGEMENT_ERROR", {
                    error,
                    item,
                    currentUrl: location.href
                }, "ERROR");
                const old = batchResults.find((x) => x.id === item.id) || {};
                setBatchResult_(item, {
                    ...old,
                    id: item.id,
                    username: item.username,
                    status: old.status === "SAVED" ? "SAVED" : "ERROR",
                    engagementError: String(error?.message || error),
                    raw: item.raw
                });
                setFinderStatus_(`Không chụp được Like/Comment ${item.id}: ${error?.message || error}`, "error");
            }

            const state = loadMultiBatchState_() || {};
            state.phase = "PROFILE";
            saveMultiBatchState_(state);
            return "NEXT";
        }

        const currentUser = normalizeUsername_(getCurrentProfileUsername_());
        const targetUser = normalizeUsername_(item.username);

        if (!targetUser) {
            setBatchResult_(item, { id: item.id, status: "ERROR", error: "Thiếu username/profile trong link.", raw: item.raw, username: item.username });
            return "NEXT";
        }

        if (!isTikTokProfilePage_() || currentUser !== targetUser) {
            debugLog_("NAVIGATE_PROFILE", {
                currentUser,
                targetUser,
                targetUrl: item.profileUrl || profileUrlForUsername_(item.username)
            });
            setFinderStatus_(`Đang mở kênh @${item.username} • ${batchIndex + 1}/${batchTargets.length}…`, "searching");
            persistCurrentBatch_();
            const state = loadMultiBatchState_() || {};
            state.phase = "PROFILE";
            saveMultiBatchState_(state);
            location.assign(item.profileUrl || profileUrlForUsername_(item.username));
            return "NAVIGATE";
        }

        renderBatchResults_();
        setFinderStatus_(`@${item.username} • ${batchIndex + 1}/${batchTargets.length}: đang tìm ${item.id}…`, "searching");

        let anchor = findVideoAnchorById_(item.id);
        debugLog_("VIDEO_FIND_INITIAL", {
            id: item.id,
            found: !!anchor,
            anchorsOnPage: document.querySelectorAll('a[href*="/video/"], a[href*="/photo/"]').length
        });
        if (!anchor) anchor = await findVideoForBatch_(item.id);
        debugLog_("VIDEO_FIND_RESULT", { id: item.id, found: !!anchor, anchor });

        if (!anchor && !batchCancelled) {
            window.scrollTo({ top: 0, left: 0, behavior: "smooth" });
            await sleep_(1200);
            anchor = await findVideoForBatch_(item.id);
        }

        if (!anchor) {
            setBatchResult_(item, { id: item.id, username: item.username, status: "NOT FOUND", raw: item.raw });
            setFinderStatus_(`Không thấy ${item.id} trên @${item.username}. Chuyển mục tiếp theo…`, "error");
            return "NEXT";
        }

        highlightFoundVideo_(anchor);
        setFinderStatus_(`Đã thấy ${item.id}. Chờ ảnh load đủ rồi chụp…`, "success");

        try {
            const saved = await captureThumbnail_(anchor, item.id, item.username);
            setBatchResult_(item, {
                id: item.id,
                username: item.username,
                status: "SAVED",
                filename: saved.filename,
                raw: item.raw
            });
            setFinderStatus_(`Đã lưu thumbnail: ${saved.filename}`, "success");
        } catch (error) {
            debugLog_("CAPTURE_THUMB_ERROR", {
                error,
                message: error?.message || String(error),
                stack: error?.stack || "",
                item,
                currentUrl: location.href
            }, "ERROR");
            setBatchResult_(item, {
                id: item.id,
                username: item.username,
                status: "ERROR",
                error: String(error?.message || error),
                raw: item.raw
            });
            setFinderStatus_(`Lỗi chụp ${item.id}: ${error?.message || error}. Tiếp tục…`, "error");
            return "NEXT";
        }

        return "NEXT";
    }

    async function continueMultiChannelBatch_() {
        if (!batchRunning || batchCancelled) return;
        setBatchPanelCompact_(true);
        updateFinderButtons_();
        renderBatchResults_();

        while (batchRunning && !batchCancelled && batchIndex < batchTargets.length) {
            const action = await processCurrentBatchTarget_();
            if (action === "NAVIGATE") return;

            batchIndex += 1;
            persistCurrentBatch_();
            renderBatchResults_();
            await sleep_(650);
        }

        if (batchCancelled) return;

        const savedCount = batchResults.filter((x) => x.status === "SAVED").length;
        const missingCount = batchResults.filter((x) => x.status === "NOT FOUND").length;
        const errorCount = batchResults.filter((x) => x.status === "ERROR").length;

        debugLog_("BATCH_COMPLETE", {
            savedCount,
            missingCount,
            errorCount,
            results: batchResults
        }, errorCount ? "WARN" : "INFO");

        batchRunning = false;
        batchCancelled = false;
        setBatchPanelCompact_(false);
        clearMultiBatchState_();
        renderBatchResults_();
        updateFinderButtons_();
        setFinderStatus_(`Hoàn tất Multi-Channel: ${savedCount}/${batchTargets.length} ảnh • Không thấy ${missingCount} • Lỗi ${errorCount}.`, savedCount ? "success" : "error");
        publishBatchProgress_(`Hoàn tất: ${savedCount}/${batchTargets.length} ảnh. ${errorCount} lỗi, ${missingCount} không thấy.`, savedCount ? "success" : "error");
    }

    async function startBatchScreenshot_() {
        if (batchRunning) return;

        clearDebugLog_();
        debugLog_("BATCH_START_CLICK", {
            userAgent: navigator.userAgent,
            platform: navigator.platform,
            language: navigator.language,
            pageUrl: location.href
        });

        const input = document.getElementById(FINDER_INPUT_ID);
        const rawInput = input ? input.value : "";
        let targets = parseFinderTargets_(rawInput);

        clearFinderHighlight_();
        stopFinder_("", "");

        if (!targets.length) {
            setFinderStatus_("Hãy dán các link video, mỗi dòng 1 link.", "error");
            return;
        }

        const missingProfile = targets.filter((x) => !x.username);
        if (missingProfile.length) {
            setFinderStatus_("Multi-Channel cần link đầy đủ có @username cho mọi video.", "error");
            return;
        }

        saveFinderTarget_(rawInput);
        const state = buildBatchState_(targets, rawInput);
        // Direct video mode: no profile scanning or thumbnail first.
        if (state.captureEngagement) state.phase = "ENGAGEMENT";
        saveMultiBatchState_(state);
        applyBatchStateToMemory_(state);
        debugLog_("BATCH_CONFIG", {
            targets,
            channels: new Set(targets.map(x => normalizeUsername_(x.username))).size,
            captureEngagement: state.captureEngagement,
            loadWaitMs: state.loadWaitMs
        });

        setBatchPanelCompact_(true);
        renderBatchResults_();
        updateFinderButtons_();

        const channels = new Set(batchTargets.map((x) => normalizeUsername_(x.username))).size;
        setFinderStatus_(`Bắt đầu ${batchTargets.length} video / ${channels} kênh…`, "searching");
        publishBatchProgress_();
        await continueMultiChannelBatch_();
    }

    function stopBatch_() {
        batchCancelled = true;
        batchRunning = false;
        clearMultiBatchState_();
        setBatchPanelCompact_(false);
        stopFinder_("Đã dừng Multi-Channel Batch.", "error");
        updateFinderButtons_();
        publishBatchProgress_("Đã dừng theo yêu cầu.", "error");
    }

    function resumeMultiChannelBatchIfNeeded_() {
        const state = loadMultiBatchState_();
        if (!state || !state.running || !Array.isArray(state.targets) || !state.targets.length) return;
        debugLog_("BATCH_RESUME_AFTER_NAVIGATION", { state });

        const panel = getOrCreateFinderPanel_();
        panel.style.display = "block";
        const input = document.getElementById(FINDER_INPUT_ID);
        if (input && state.rawInput) input.value = state.rawInput;

        applyBatchStateToMemory_(state);
        const engagementOpt = document.querySelector('[data-option="engagement"]');
        const loadWaitOpt = document.querySelector('[data-option="load-wait"]');
        if (engagementOpt) engagementOpt.checked = !!state.captureEngagement;
        if (loadWaitOpt && state.loadWaitMs) loadWaitOpt.value = String(state.loadWaitMs);
        setBatchPanelCompact_(true);
        renderBatchResults_();
        updateFinderButtons_();
        publishBatchProgress_(`Tiếp tục ${batchIndex + 1}/${batchTargets.length}…`, "searching");

        setTimeout(() => {
            if (batchRunning && !batchCancelled) continueMultiChannelBatch_();
        }, 900);
    }

    function updateFinderButtons_() {
        const panel = document.getElementById(FINDER_PANEL_ID);
        if (!panel) return;
        const start = panel.querySelector('[data-action="start"]');
        const batch = panel.querySelector('[data-action="batch"]');
        const stop = panel.querySelector('[data-action="stop"]');
        const clear = panel.querySelector('[data-action="clear-highlight"]');
        const busy = finderRunning || batchRunning;
        if (start) start.disabled = busy;
        if (batch) batch.disabled = busy;
        if (stop) stop.disabled = !busy;
        if (clear) clear.disabled = !finderHighlighted;
    }

    function closeFinderPanel_() {
        const panel = document.getElementById(FINDER_PANEL_ID);
        if (panel) panel.style.display = "none";
    }

    function openFinderPanel_() {
        const panel = getOrCreateFinderPanel_();
        panel.style.display = "block";
        const input = document.getElementById(FINDER_INPUT_ID);
        if (input) {
            if (!input.value) input.value = loadFinderTarget_();
            setTimeout(() => input.focus(), 0);
        }
        updateFinderButtons_();
    }

    function getOrCreateFinderPanel_() {
        let panel = document.getElementById(FINDER_PANEL_ID);
        if (panel) return panel;

        panel = document.createElement("div");
        panel.id = FINDER_PANEL_ID;
        panel.innerHTML = `
            <div class="tt-profile-finder-head">
                <strong>Multi-Channel Video Finder</strong>
                <button type="button" data-action="close" title="Đóng">×</button>
            </div>
            <label class="tt-profile-finder-label" for="${FINDER_INPUT_ID}">Link TikTok Video — hỗ trợ nhiều kênh, mỗi dòng 1 video</label>
            <textarea id="${FINDER_INPUT_ID}" rows="6" autocomplete="off" spellcheck="false" placeholder="https://www.tiktok.com/@.../video/...\nhttps://www.tiktok.com/@.../video/..."></textarea>
            <div class="tt-profile-finder-note">Dán link từ nhiều @kênh. Chỉ Views: tìm thumbnail trên Profile. Bật Engagement: mở thẳng Video và chụp một ảnh có Views + Like/Comment/Share.</div>
            <div class="tt-batch-options">
                <label class="tt-batch-option">
                    <input type="checkbox" data-option="engagement">
                    <span>Chụp Views + Engagement trong một ảnh (mở thẳng VDO)</span>
                </label>
                <label class="tt-batch-option tt-batch-delay">
                    <span>Chờ ảnh load</span>
                    <select data-option="load-wait">
                        <option value="800">0.8s</option>
                        <option value="1400" selected>1.4s</option>
                        <option value="2000">2.0s</option>
                        <option value="3000">3.0s</option>
                    </select>
                </label>
            </div>
            <div class="tt-profile-finder-actions">
                <button type="button" data-action="start">Tìm VDO đầu tiên</button>
                <button type="button" data-action="batch">📸 Multi-Channel Batch</button>
                <button type="button" data-action="stop">Dừng</button>
                <button type="button" data-action="clear-highlight">Tắt Highlight</button>
                <button type="button" data-action="download-log">⬇ Tải Debug Log</button>
                <button type="button" data-action="clear-log">Xóa Log</button>
            </div>
            <div class="tt-debug-log-bar">
                <span>Debug: <strong id="tt-debug-log-count">0 log</strong></span>
                <span>Nếu có “Tìm thấy nhưng lỗi chụp”, tải Log gửi lại để xem đúng lỗi.</span>
            </div>
            <div id="${FINDER_STATUS_ID}" class="tt-profile-finder-status">Dán list link TikTok Video từ một hoặc nhiều kênh rồi chạy Batch.</div>
            <div id="${FINDER_RESULTS_ID}" class="tt-profile-finder-results" style="display:none"></div>
        `;

        (document.body || document.documentElement).appendChild(panel);

        panel.querySelector('[data-action="close"]').addEventListener("click", closeFinderPanel_);
        panel.querySelector('[data-action="start"]').addEventListener("click", startFinder_);
        panel.querySelector('[data-action="batch"]').addEventListener("click", startBatchScreenshot_);
        panel.querySelector('[data-action="stop"]').addEventListener("click", () => {
            if (batchRunning) stopBatch_();
            else stopFinder_();
        });
        panel.querySelector('[data-action="clear-highlight"]').addEventListener("click", () => {
            clearFinderHighlight_();
            setFinderStatus_("Đã tắt Highlight. Giao diện đã về nguyên bản.", "success");
        });
        panel.querySelector('[data-action="download-log"]').addEventListener("click", () => {
            downloadDebugLog_().catch((error) => {
                debugLog_("LOG_EXPORT_ERROR", { error }, "ERROR");
                setFinderStatus_(`Không tải được Log: ${error?.message || error}`, "error");
            });
        });
        panel.querySelector('[data-action="clear-log"]').addEventListener("click", () => {
            clearDebugLog_();
            setFinderStatus_("Đã xóa Debug Log.", "success");
        });
        updateDebugCounter_();

        const input = panel.querySelector(`#${FINDER_INPUT_ID}`);
        input.value = loadFinderTarget_();
        input.addEventListener("input", () => {
            if (!batchRunning) {
                batchTargets = [];
                batchResults = [];
                renderBatchResults_();
            }
        });
        input.addEventListener("keydown", (event) => {
            if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
                event.preventDefault();
                startBatchScreenshot_();
            } else if (event.key === "Escape") {
                closeFinderPanel_();
            }
        });

        return panel;
    }

    function getOrCreateFinderButton_() {
        let button = document.getElementById(FINDER_BUTTON_ID);
        if (button) return button;

        button = document.createElement("button");
        button.id = FINDER_BUTTON_ID;
        button.type = "button";
        button.textContent = "🔎 Tìm / Chụp VDO";
        button.title = "Tự mở nhiều profile, tìm video và chụp screenshot hàng loạt";
        button.addEventListener("click", openFinderPanel_);
        (document.body || document.documentElement).appendChild(button);
        return button;
    }

    function refreshFinderUi_() {
        if (!document.body) return;
        const button = getOrCreateFinderButton_();
        // Multi-channel batch có thể bắt đầu từ bất kỳ trang TikTok nào.
        button.style.display = "block";

        // Single Finder vẫn yêu cầu profile, nhưng Multi-Channel được phép tự chuyển profile.
        if (!isTikTokProfilePage_() && finderRunning && !batchRunning) {
            stopFinder_("Đã rời trang profile.", "error");
        }
    }

    // Chrome Side Panel -> service worker -> TikTok content script.
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
        if (!message || !message.type) return;
        if (message.type === "TT_PING_CONTENT") {
            sendResponse({ ok: true, version: DEBUG_VERSION });
            return;
        }
        if (message.type === "TT_EXTERNAL_START_BATCH") {
            if (batchRunning || loadMultiBatchState_()?.running) {
                sendResponse({ ok: false, error: "Đang có Batch chạy trên tab này." });
                return;
            }
            const raw = String(message.rawInput || "").trim();
            const targets = parseFinderTargets_(raw);
            if (!targets.length || targets.some(item => !item.username || !/^https:\/\/www\.tiktok\.com\/@[^\s/]+\/(?:video|photo)\/\d{8,}/i.test(item.raw))) {
                sendResponse({ ok: false, error: "Yêu cầu link TikTok đầy đủ có @username/video/ID." });
                return;
            }
            const panel = getOrCreateFinderPanel_();
            panel.style.display = "block";
            const input = document.getElementById(FINDER_INPUT_ID);
            if (input) input.value = raw;
            const engagementOpt = panel.querySelector('[data-option="engagement"]');
            if (engagementOpt) engagementOpt.checked = !!message.captureEngagement;
            const waitOpt = panel.querySelector('[data-option="load-wait"]');
            if (waitOpt) waitOpt.value = String([800, 1400, 2000, 3000].includes(Number(message.loadWaitMs))
                ? message.loadWaitMs : 1400);
            sendResponse({ ok: true });
            startBatchScreenshot_().catch(error => {
                debugLog_("EXTERNAL_BATCH_ERROR", { error }, "ERROR");
                stopBatch_();
                publishBatchProgress_(String(error?.message || error), "error");
            });
            return;
        }
        if (message.type === "TT_EXTERNAL_STOP_BATCH") {
            if (batchRunning) stopBatch_();
            sendResponse({ ok: true });
            return;
        }
        if (message.type === "TT_EXTERNAL_DEBUG_LOG") {
            downloadDebugLog_().then(() => sendResponse({ ok: true }))
                .catch(error => sendResponse({ ok: false, error: String(error?.message || error) }));
            return true;
        }
    });

    const finderObserver = new MutationObserver(() => {
        refreshFinderUi_();
        if (finderRunning && !batchRunning && finderTargetId) {
            const found = findVideoAnchorById_(finderTargetId);
            if (found) {
                highlightFoundVideo_(found);
                stopFinder_(`Đã tìm thấy Video ID ${finderTargetId}.`, "success");
            }
        }
    });

    if (document.documentElement) {
        finderObserver.observe(document.documentElement, { childList: true, subtree: true });
    }

    const finderUiTimer = setInterval(refreshFinderUi_, 1200);
    window.addEventListener("pagehide", () => clearInterval(finderUiTimer), { once: true });
    setTimeout(refreshFinderUi_, 0);
    setTimeout(resumeMultiChannelBatchIfNeeded_, 1100);

})();

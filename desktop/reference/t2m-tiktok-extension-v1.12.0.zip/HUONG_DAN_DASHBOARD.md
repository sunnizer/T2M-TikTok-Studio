# T2M Extension Manager — hướng dẫn triển khai

## 1. Mã nguồn và phần đã hoàn tất

- Chrome Extension v1.12.0 có nút **Install / Tải bản mới**, **Kiểm tra Update** và **Chrome Extensions** trong Side Panel.
- Website quản lý mã nguồn ở thư mục `dashboard/` dùng HTML/CSS/JavaScript thuần. Không có GitHub token ở frontend.
- GitHub Actions tự Build trong `build-extension.yml` (tự động chạy khi push và cho phép chạy thủ công).
- GitHub Actions **Publish Extension Release** trong `release-extension.yml` (chỉ chạy khi chủ repo bấm Run workflow).
- Release tạo một asset ổn định: `t2m-tiktok-extension.zip`, website Download sẽ trỏ về bản release mới nhất.

## 2. Upload vào GitHub

Đưa **nội dung** thư mục này vào gốc repo `sunnizer/t2m-tiktok-extension` sao cho:

- `manifest.json` ở root
- `dashboard/index.html`, `dashboard/styles.css`, `dashboard/app.js`, `dashboard/vercel.json` cùng thư mục
- `.github/workflows/release-extension.yml` (lưu ý thư mục ẩn `.github`)

Nếu trình duyệt không giữ thư mục ẩn `.github` khi kéo-thả, tạo workflow bằng GitHub > Actions > New workflow hoặc upload riêng với đường dẫn `.github/workflows/release-extension.yml`.

Không upload file ZIP đóng gói ở cấp root thay cho mã nguồn.

## 3. Tạo website trên Vercel

1. Vercel > Add New > Project.
2. Import private GitHub repository `sunnizer/t2m-tiktok-extension`.
3. Project Name: `t2m-extension-manager`.
4. Root Directory: `dashboard` (**bắt buộc**).
5. Framework Preset: Other; không cần build command/output directory.
6. Deploy. Bạn có thể bật Vercel Authentication để chỉ tài khoản được phép vào website quản lý.
7. Các push tiếp theo vào nhánh main sẽ tự deploy giao diện Dashboard.

> Không sử dụng Vercel Dashboard này như giao diện admin không cần đăng nhập. Các nút Build/Release mở GitHub Actions, nơi GitHub xác thực người có quyền.

## 4. Cách bấm Update

- Sửa mã: sửa version `manifest.json` và file tương ứng, commit/push main.
- GitHub Actions > Build TikTok Extension > Run workflow (tự chạy sau mỗi push).
- Test ZIP trong Artifact. Artifact lưu 30 ngày.
- GitHub Actions > Publish Extension Release > Run workflow.
- Tải ZIP từ Dashboard bằng **Download ZIP**.
- `Load unpacked`: giải nén vào **cùng thư mục đã cài** trên máy và vào `chrome://extensions` nhấn Reload. Không có cách an toàn để website tự cài đè Extension unpacked.
- Chrome Web Store: sau khi xuất bản chính thức, Chrome tự tải các bản cập nhật được duyệt. Nút **Kiểm tra Update** trong Side Panel gọi `chrome.runtime.requestUpdateCheck()` khi người dùng bấm.

## 5. Chưa được thiết lập

- Chưa có Chrome Web Store ID, Developer OAuth hay Chrome Web Store API để Publish Store tự động.
- Website hiện dùng GitHub Releases với repo private. Người tải phải đăng nhập tài khoản có quyền xem repo.
- Không có thao tác Install một click từ website (Chrome không hỗ trợ inline install).
- Không có GitHub/Vercel token ở trình duyệt.

## 6. Quyền chụp ảnh

Do extension tự mở tab TikTok từ Side Panel rồi chụp `chrome.tabs.captureVisibleTab`, bản Beta hiện giữ `<all_urls>` để không phá tính năng Batch. API Chrome yêu cầu `<all_urls>` hoặc `activeTab`; quyền `activeTab` được cấp theo thao tác trên một tab và có thể không áp dụng cho tab TikTok mới mở tự động. Trước khi lên Web Store cần xét lại mô hình quyền để giảm cảnh báo, nhưng không được gỡ quyền khi chưa kiểm thử screenshot thực tế.

// TikTok View Counter v1.12.0
// Force screenshot filenames/subfolder through chrome.downloads API.

const pendingScreenshotNames = new Map();

function sanitizeRelativeFilename_(raw) {
  let requested = String(raw || "").trim();

  requested = requested
    .replace(/\\/g, "/")
    .replace(/[\x00-\x1f:*?"<>|]/g, "-")
    .replace(/^\/+/, "")
    .replace(/\/{2,}/g, "/");

  if (!requested) {
    const d = new Date();
    const pad = (n, len = 2) => String(n).padStart(len, "0");
    requested = `Screenshot/${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}_${pad(d.getMilliseconds(),3)}.png`;
  }

  if (!/\.(png|jpe?g)$/i.test(requested)) requested += ".jpg";

  // Always save screenshots inside Downloads/Screenshot/.
  const base = requested.split("/").pop() || "screenshot.jpg";
  return `Screenshot/${base}`;
}

// Extra safety layer: Chrome may try to infer a generic filename such as
// "download.png" / "Screenshot (1).png" from a data URL. When the URL belongs
// to one of our pending screenshots, override that inferred name explicitly.
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  const forcedName = pendingScreenshotNames.get(item.url);
  if (!forcedName) return;

  pendingScreenshotNames.delete(item.url);
  suggest({
    filename: forcedName,
    conflictAction: "uniquify"
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;

  if (message.type === "TT_CAPTURE_VISIBLE_TAB") {
    const windowId = sender?.tab?.windowId;
    const tabId = sender?.tab?.id;
    if (!Number.isInteger(tabId)) {
      sendResponse({ ok: false, error: "Chỉ chụp được tab TikTok hợp lệ." });
      return;
    }
    // captureVisibleTab captures ACTIVE tab, NOT sender.tab. Never silently
    // screenshot another website if user switched tabs while a batch is running.
    chrome.tabs.query({ active: true, windowId }, (tabs) => {
      if (chrome.runtime.lastError || tabs?.[0]?.id !== tabId) {
        sendResponse({ ok: false, error: "Hãy giữ tab TikTok đang xử lý ở phía trước khi chụp ảnh." });
        return;
      }
      chrome.tabs.captureVisibleTab(windowId, { format: "png" }, (dataUrl) => {
        if (chrome.runtime.lastError || !dataUrl) {
          sendResponse({ ok: false, error: chrome.runtime.lastError?.message || "Chụp màn hình thất bại." });
          return;
        }
        sendResponse({ ok: true, dataUrl, windowId, tabId, tabUrl: sender?.tab?.url || "" });
      });
    });
    return true;
  }

  if (message.type === "TT_DOWNLOAD_DEBUG_LOG") {
    const base = String(message.baseName || `TikTok_Debug_${Date.now()}`)
      .replace(/[\\/:*?"<>|]/g, "-");

    const txtUrl = "data:text/plain;charset=utf-8," + encodeURIComponent(String(message.txt || ""));
    const jsonUrl = "data:application/json;charset=utf-8," + encodeURIComponent(String(message.json || "{}"));

    const txtFilename = `TikTok Debug Logs/${base}.txt`;
    const jsonFilename = `TikTok Debug Logs/${base}.json`;

    chrome.downloads.download({
      url: txtUrl,
      filename: txtFilename,
      saveAs: false,
      conflictAction: "uniquify"
    }, (txtId) => {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, error: `TXT: ${chrome.runtime.lastError.message}` });
        return;
      }

      chrome.downloads.download({
        url: jsonUrl,
        filename: jsonFilename,
        saveAs: false,
        conflictAction: "uniquify"
      }, (jsonId) => {
        if (chrome.runtime.lastError) {
          sendResponse({
            ok: false,
            error: `JSON: ${chrome.runtime.lastError.message}`,
            txtDownloadId: txtId,
            txtFilename
          });
          return;
        }

        sendResponse({
          ok: true,
          txtDownloadId: txtId,
          jsonDownloadId: jsonId,
          txtFilename,
          jsonFilename
        });
      });
    });

    return true;
  }

  if (message.type === "TT_DOWNLOAD_SCREENSHOT") {
    const requested = sanitizeRelativeFilename_(message.filename);
    const downloadUrl = String(message.dataUrl || "");

    if (!downloadUrl) {
      sendResponse({ ok: false, error: "Không có dữ liệu ảnh để lưu." });
      return;
    }

    // Register before starting the download so onDeterminingFilename can force it.
    pendingScreenshotNames.set(downloadUrl, requested);

    chrome.downloads.download({
      url: downloadUrl,
      filename: requested,
      saveAs: false,
      conflictAction: "uniquify"
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        pendingScreenshotNames.delete(downloadUrl);
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }

      // Clean stale mapping if onDeterminingFilename was not fired for any reason.
      setTimeout(() => pendingScreenshotNames.delete(downloadUrl), 10000);

      // Wait a little longer than previous builds so Chrome has resolved the
      // final filesystem path before we report it back to the content script.
      setTimeout(() => {
        chrome.downloads.search({ id: downloadId }, (items) => {
          const actual = items && items[0] && items[0].filename
            ? items[0].filename
            : requested;

          sendResponse({
            ok: true,
            downloadId,
            requestedFilename: requested,
            actualFilename: actual
          });
        });
      }, 350);
    });

    return true;
  }
});


/* ================================================================
 * v1.11.0 — Chrome global Side Panel orchestrator.
 * A user starts from ANY site. TikTok processing still happens in a
 * foreground TikTok tab, because screenshots capture visible tab only.
 * ================================================================= */
const TT_SIDE_STATUS_KEY = "tt_sidepanel_job_v1";

async function setPanelBehavior_() {
  try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }); }
  catch (error) { console.warn("TikTok panel setup", error); }
}
chrome.runtime.onInstalled.addListener(setPanelBehavior_);
chrome.runtime.onStartup.addListener(setPanelBehavior_);
setPanelBehavior_();

async function readJob_() {
  const current = await chrome.storage.local.get(TT_SIDE_STATUS_KEY);
  return current[TT_SIDE_STATUS_KEY] || null;
}
async function putJob_(job) {
  await chrome.storage.local.set({ [TT_SIDE_STATUS_KEY]: job });
}
function parseDirectLinks_(text) {
  const rows = String(text || "").trim().split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  if (!rows.length || rows.length > 500) throw new Error("Nhập 1–500 link TikTok, mỗi dòng một link.");
  const valid = [];
  const seen = new Set();
  for (const row of rows) {
    let u;
    try { u = new URL(row); } catch (_) { throw new Error(`Link không hợp lệ: ${row.slice(0, 80)}`); }
    if (u.protocol !== "https:" || u.hostname !== "www.tiktok.com" ||
        !/^\/@[^/]+\/(video|photo)\/\d{8,}\/?$/.test(u.pathname)) {
      throw new Error(`Chỉ nhận https://www.tiktok.com/@user/video/ID (hoặc /photo/): ${row.slice(0, 80)}`);
    }
    const id = u.pathname.match(/\d{8,}/)?.[0];
    if (seen.has(id)) continue;
    seen.add(id);
    valid.push(u.origin + u.pathname);
  }
  return valid;
}
async function sleepJob_(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

async function startPanelJob_(message) {
  const urls = parseDirectLinks_(message.rawInput);
  const oldJob = await readJob_();
  if (oldJob?.running && Number.isInteger(oldJob.tabId)) {
    try { await chrome.tabs.get(oldJob.tabId); throw new Error("Đang có Batch chạy. Hãy bấm Dừng trước khi chạy mới."); }
    catch (e) { if (e.message?.includes("Đang có Batch")) throw e; }
  }
  const captureEngagement = !!message.captureEngagement;
  if (captureEngagement && urls.some(x => /\/photo\//i.test(x))) {
    throw new Error("Chế độ Engagement chỉ hỗ trợ video. Hãy bỏ link /photo/ hoặc tắt Engagement.");
  }
  const loadWaitMs = [800, 1400, 2000, 3000].includes(Number(message.loadWaitMs))
    ? Number(message.loadWaitMs) : 1400;
  const firstUrl = captureEngagement
    ? urls[0]
    : `https://www.tiktok.com/${urls[0].split("/")[3]}`;
  const tab = await chrome.tabs.create({ url: firstUrl, active: true });
  const job = {
    running: true, tabId: tab.id, startedAt: Date.now(), updatedAt: Date.now(),
    total: urls.length, index: 0, captureEngagement,
    status: "Đang mở tab TikTok và kết nối Extension…", statusType: "searching", results: []
  };
  await putJob_(job);
  // Chrome occasionally loads a splash/challenge page first: retry message,
  // but never auto-reload to get around access restrictions.
  let lastError = "";
  for (let i = 0; i < 24; i++) {
    try {
      await chrome.tabs.get(tab.id);
      const response = await chrome.tabs.sendMessage(tab.id, {
        type: "TT_EXTERNAL_START_BATCH", rawInput: urls.join("\n"),
        captureEngagement, loadWaitMs
      });
      if (!response?.ok) throw new Error(response?.error || "Không khởi tạo được Batch.");
      return { ok: true, tabId: tab.id, total: urls.length };
    } catch (error) {
      lastError = String(error.message || error);
      if (!lastError.includes("Receiving end does not exist") &&
          !lastError.includes("Could not establish connection") &&
          !lastError.includes("No tab with id")) break;
      await sleepJob_(550);
    }
  }
  await putJob_({ ...job, running: false, statusType: "error",
    status: `Không thể kết nối TikTok: ${lastError}. Kiểm tra đăng nhập/chặn truy cập.` });
  return { ok: false, error: lastError || "Không khởi tạo được Extension trên TikTok." };
}

async function stopPanelJob_() {
  const job = await readJob_();
  if (!job?.running) return { ok: true };
  await putJob_({ ...job, running: false, statusType: "error", updatedAt: Date.now(), status: "Đã dừng theo yêu cầu." });
  if (Number.isInteger(job.tabId)) {
    try { await chrome.tabs.sendMessage(job.tabId, { type: "TT_EXTERNAL_STOP_BATCH" }); }
    catch (_) { /* Navigation in progress; closing only our owned tab is reliable. */ }
    try { await chrome.tabs.remove(job.tabId); } catch (_) {}
  }
  return { ok: true };
}

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const job = await readJob_();
  if (job?.tabId === tabId && job.running) {
    await putJob_({ ...job, running: false, statusType: "error",
      updatedAt: Date.now(), status: "Tab TikTok xử lý đã bị đóng." });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== "string") return;
  if (message.type === "TT_UI_START_BATCH") {
    if (sender.url && !sender.url.startsWith(chrome.runtime.getURL("sidepanel.html"))) {
      sendResponse({ ok: false, error: "Chỉ bảng điều khiển mới có thể khởi tạo Batch." });
      return;
    }
    startPanelJob_(message).then(sendResponse).catch(error =>
      sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }
  if (message.type === "TT_UI_STOP_BATCH") {
    stopPanelJob_().then(sendResponse).catch(error =>
      sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }
  if (message.type === "TT_UI_OPEN_TIKTOK_TAB") {
    readJob_().then(async job => {
      if (!Number.isInteger(job?.tabId)) return sendResponse({ ok: false, error: "Không có tab Batch." });
      const tab = await chrome.tabs.get(job.tabId);
      await chrome.tabs.update(tab.id, { active: true });
      await chrome.windows.update(tab.windowId, { focused: true });
      sendResponse({ ok: true });
    }).catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }
  if (message.type === "TT_UI_DEBUG_LOG") {
    readJob_().then(async job => {
      if (!Number.isInteger(job?.tabId)) throw new Error("Chưa có tab Batch.");
      const res = await chrome.tabs.sendMessage(job.tabId, { type: "TT_EXTERNAL_DEBUG_LOG" });
      sendResponse(res || { ok: false, error: "Không xuất được log." });
    }).catch(error => sendResponse({ ok: false, error: String(error.message || error) }));
    return true;
  }
  if (message.type === "TT_BATCH_PROGRESS" && sender.tab?.id) {
    (async () => {
      const job = await readJob_();
      if (job?.tabId !== sender.tab.id || !job.running) return;
      const payload = message.payload || {};
      await putJob_({ ...job,
        running: !!payload.running, updatedAt: Date.now(),
        index: Math.max(0, Number(payload.index) || 0),
        total: Math.max(0, Number(payload.total) || job.total),
        status: String(payload.status || job.status).slice(0, 360),
        statusType: String(payload.statusType || job.statusType),
        results: Array.isArray(payload.results) ? payload.results.slice(-500) : job.results
      });
    })().catch(error => console.warn("TikTok progress", error));
    sendResponse({ ok: true });
    return;
  }
});

// TikTok View Counter v1.12.0 — globally available Chrome Side Panel
const JOB_KEY = 'tt_sidepanel_job_v1';
const DRAFT_KEY = 'tt_sidepanel_draft_v1';
const q = (id) => document.getElementById(id);
let currentJob = null;
let saving = false;
function notify(text) { q('toast').textContent = String(text || ''); }

async function sendCommand(type, data = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, ...data }, (response) => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else if (!response?.ok) reject(new Error(response?.error || 'Yêu cầu không thành công.'));
      else resolve(response);
    });
  });
}

function showJob(job) {
  currentJob = job || null;
  const running = !!job?.running;
  q('start').disabled = running;
  q('stop').disabled = !running;
  const results = Array.isArray(job?.results) ? job.results : [];
  const done = results.length;
  const total = Math.max(0, Number(job?.total) || 0);
  q('counter').textContent = `${done}/${total}`;
  q('progress').style.width = `${total ? Math.min(100, 100 * done / total) : 0}%`;
  const status = q('status');
  status.textContent = job?.status || 'Sẵn sàng. Dán link rồi bấm Bắt đầu.';
  status.dataset.type = job?.statusType || '';
  q('open-tab').disabled = !Number.isInteger(job?.tabId);
  q('download-log').disabled = !Number.isInteger(job?.tabId);
  const list = q('results');
  list.replaceChildren();
  for (const result of results) {
    const row = document.createElement('div');
    row.className = 'result-row';
    row.dataset.status = result.status || '';
    const icon = document.createElement('span');
    icon.className = 'result-icon';
    icon.textContent = result.status === 'SAVED' ? '✓' : (result.status === 'ERROR' ? '!' : '×');
    const main = document.createElement('div');
    main.className = 'result-main';
    const name = document.createElement('strong');
    name.textContent = `${result.status === 'SAVED' ? 'Đã lưu' : result.status === 'ERROR' ? 'Lỗi' : 'Không tìm thấy'} • @${result.username || '?'} / ${result.id || ''}`;
    const file = document.createElement('small');
    file.textContent = result.engagementFilename || result.filename || result.engagementError || result.error || '';
    main.append(name, file);
    row.append(icon, main);
    list.appendChild(row);
  }
}

async function saveDraft() {
  const draft = {
    rawInput: q('links').value,
    captureEngagement: q('engagement').checked,
    loadWaitMs: Number(q('load-wait').value)
  };
  await chrome.storage.local.set({ [DRAFT_KEY]: draft });
}
async function initialize() {
  try {
    const data = await chrome.storage.local.get([JOB_KEY, DRAFT_KEY]);
    const draft = data[DRAFT_KEY] || {};
    q('links').value = draft.rawInput || '';
    q('engagement').checked = !!draft.captureEngagement;
    q('load-wait').value = String(draft.loadWaitMs || 1400);
    showJob(data[JOB_KEY]);
  } catch (error) { notify(error.message); }
}
q('links').addEventListener('input', () => { saveDraft().catch(() => {}); });
q('engagement').addEventListener('change', () => { saveDraft().catch(() => {}); });
q('load-wait').addEventListener('change', () => { saveDraft().catch(() => {}); });

q('start').addEventListener('click', async () => {
  if (saving) return;
  saving = true;
  q('start').disabled = true;
  notify('');
  try {
    await saveDraft();
    await sendCommand('TT_UI_START_BATCH', {
      rawInput: q('links').value,
      captureEngagement: q('engagement').checked,
      loadWaitMs: Number(q('load-wait').value)
    });
  } catch (error) { notify(error.message); }
  finally { saving = false; if (!currentJob?.running) q('start').disabled = false; }
});
q('stop').addEventListener('click', async () => {
  notify('');
  try { await sendCommand('TT_UI_STOP_BATCH'); }
  catch (error) { notify(error.message); }
});
q('open-tab').addEventListener('click', async () => {
  notify('');
  try { await sendCommand('TT_UI_OPEN_TIKTOK_TAB'); }
  catch (error) { notify(error.message); }
});
q('download-log').addEventListener('click', async () => {
  notify('');
  try { await sendCommand('TT_UI_DEBUG_LOG'); }
  catch (error) { notify(error.message); }
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes[JOB_KEY]) showJob(changes[JOB_KEY].newValue);
});
initialize();


// v1.12.0: Installation link and manual, user-triggered update check.
// No remote JS is fetched or executed. Store updates remain Chrome-controlled.
const RELEASES_URL = 'https://github.com/sunnizer/t2m-tiktok-extension/releases/latest';
const currentVersion = chrome.runtime.getManifest().version;
q('local-version').textContent = 'v' + currentVersion;
q('update-status').textContent = 'Phiên bản đang dùng: v' + currentVersion;
q('install-guide').addEventListener('click', async () => {
  try { await chrome.tabs.create({url: RELEASES_URL}); }
  catch (e) { q('update-status').textContent = 'Không mở được trang phát hành: ' + e.message; }
});
q('manage-extensions').addEventListener('click', async () => {
  try { await chrome.tabs.create({url:'chrome://extensions/'}); }
  catch (_e) { q('update-status').textContent = 'Mở chrome://extensions trên thanh địa chỉ để quản lý Extension.'; }
});
q('check-update').addEventListener('click', async () => {
  const btn=q('check-update');
  btn.disabled=true;
  q('update-status').textContent='Đang yêu cầu Chrome kiểm tra phiên bản trên Web Store…';
  try {
    const result=await chrome.runtime.requestUpdateCheck();
    if(result.status==='update_available'){
      q('update-status').textContent=`Chrome đã tìm thấy v${result.version || '?'}; bản mới sẽ cài khi Extension không còn hoạt động.`;
    } else if(result.status==='throttled'){
      q('update-status').textContent='Chrome đang giới hạn số lần kiểm tra. Vui lòng thử lại sau.';
    } else {
      q('update-status').textContent='Chưa có bản cập nhật trên Chrome Web Store. Nếu cài qua Load unpacked, hãy tải bản ZIP mới và Reload thủ công.';
    }
  } catch (e) {
    q('update-status').textContent='Không kiểm tra được Web Store: ' + e.message + '. Bản Load unpacked cần cập nhật thủ công.';
  } finally {btn.disabled=false;}
});

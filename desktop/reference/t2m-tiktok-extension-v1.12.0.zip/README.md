# T2M TikTok Extension

T2M TikTok Views & Engagement screenshot Chrome Extension (Manifest V3) và bảng quản lý phiên bản.

## Cấu trúc

- `manifest.json`, `background.js`, `content.js`, `sidepanel.*`, `style.css`, `icon*.png`: mã nguồn Extension.
- `dashboard/`: T2M Extension Manager, triển khai Vercel với **Root Directory = dashboard**.
- `.github/workflows/build-extension.yml`: tự kiểm tra và đóng gói ZIP khi push hoặc bấm Run workflow.
- `.github/workflows/release-extension.yml`: bấm Run workflow để phát hành GitHub Release sau khi đã tăng version trong `manifest.json`.
- `tools/build_extension.py`: lệnh tạo ZIP bằng Python 3.12.
- `HUONG_DAN_DASHBOARD.md`: hướng dẫn upload và triển khai bằng tiếng Việt.

## Cài đặt và phát hành

Chạy `python tools/build_extension.py` để tạo ZIP trong `dist/`. Bản thử nghiệm Chrome `Load unpacked` cần giải nén, cập nhật file vào cùng thư mục rồi nhấn **Reload** tại `chrome://extensions`. Chrome Web Store tự quản lý cập nhật sau khi phát hành chính thức.

Dashboard dùng link tới GitHub Actions và Releases, không truy cập repo private qua token công khai. Chưa kết nối API Chrome Web Store.

© T2M. Private source code.

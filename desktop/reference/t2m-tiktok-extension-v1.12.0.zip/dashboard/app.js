'use strict';
// No privileged GitHub token is used here. Private-repository actions open GitHub
// where the signed-in repository owner authorizes them.
const OWNER = 'sunnizer';
const REPO = 't2m-tiktok-extension';
const ROOT = `https://github.com/${OWNER}/${REPO}`;
const WORKFLOWS = `${ROOT}/actions/workflows`;
const $ = id => document.getElementById(id);
const href = (id, url) => { $(id).href = url; };
href('github-top', ROOT);
href('all-releases', `${ROOT}/releases`);
href('dialog-release', `${ROOT}/releases`);
href('download-zip', `${ROOT}/releases/latest/download/t2m-tiktok-extension.zip`);
href('build-action', `${WORKFLOWS}/build-extension.yml`);
href('build-runs', `${WORKFLOWS}/build-extension.yml`);
href('release-action', `${WORKFLOWS}/release-extension.yml`);
$('year').textContent = new Date().getFullYear();
const dialog = $('install-dialog');
$('install-button').addEventListener('click', () => { $('dialog-title').textContent = 'Cài đặt TikTok Extension'; dialog.showModal(); });
$('update-button').addEventListener('click', () => { $('dialog-title').textContent = 'Cập nhật TikTok Extension'; dialog.showModal(); });
let lastToastTimeout = 0;
function toast(message) {
  const node = $('toast');
  node.textContent = message;
  node.classList.add('show');
  clearTimeout(lastToastTimeout);
  lastToastTimeout = setTimeout(() => node.classList.remove('show'), 3300);
}
$('copy-chrome').addEventListener('click', async () => {
  try { await navigator.clipboard.writeText('chrome://extensions/'); toast('Đã sao chép chrome://extensions/'); }
  catch { toast('Nhập chrome://extensions trên thanh địa chỉ Chrome.'); }
});
const navLinks = [...document.querySelectorAll('.nav-item')];
navLinks.forEach(a => a.addEventListener('click', () => {
  navLinks.forEach(x => x.classList.remove('active'));
  a.classList.add('active');
}));
